﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 纵横断面计算
{
    public class Point1
    {
        public string pointName;
        public double X;
        public double Y;
        public double Z;
        public double licheng;
    }
    class Calculate
    {
        #region 方位角计算
        /// <summary>
        /// 计算方位角
        /// </summary>
        /// <param name="pt1"></param>
        /// <param name="pt2"></param>
        /// <returns></returns>
        public static double fangwei(Point1 pt1, Point1 pt2)
        {
            double fangweijiao;
            fangweijiao = 180 - 90 * Math.Abs(pt2.Y - pt1.Y) / (pt2.Y - pt1.Y + Math.Pow(10, -10)) - Math.Atan((pt2.X - pt1.X) / (pt2.Y - pt1.Y + Math.Pow(10, -10))) * 180 / Math.PI;
            return fangweijiao * Math.PI / 180;
        }
        #endregion
        #region 距离计算
        /// <summary>
        /// 计算距离
        /// </summary>
        /// <param name="pt1"></param>
        /// <param name="pt2"></param>
        /// <returns></returns>
        public static double Distance(Point1 pt1, Point1 pt2)
        {
            double d;
            d = Math.Sqrt((pt2.X - pt1.X) * (pt2.X - pt1.X) + (pt2.Y - pt1.Y) * (pt2.Y - pt1.Y));
            return d;
        }
        #endregion
    }
}
