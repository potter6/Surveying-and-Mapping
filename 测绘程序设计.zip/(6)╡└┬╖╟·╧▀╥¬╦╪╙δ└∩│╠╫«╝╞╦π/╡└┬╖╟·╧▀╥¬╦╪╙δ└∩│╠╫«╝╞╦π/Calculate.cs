﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 道路曲线要素与里程桩计算
{
    public class Point1//起点和终点
    {
        public string _name;//点名
        public double _X;//X坐标
        public double _Y;//Y坐标
        public double _licheng;//里程
        public string QXLX;//曲线类型
    }
    class Calculate
    {
        #region 计算方位角
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="y1"></param>
        /// <param name="x2"></param>
        /// <param name="y2"></param>
        /// <returns></returns>
        public double fangweijiao(double x1, double y1, double x2, double y2)
        {
            double fangweijiao;
            fangweijiao = 180 - 90 * Math.Abs(y2 - y1) / ((y2 - y1) + Math.Pow(10, -10)) - Math.Atan((x2 - x1) / ((y2 - y1) + Math.Pow(10, -10))) * 180 / Math.PI;
            return fangweijiao * Math.PI / 180;//返回弧度值
            #region 作废
            ////sitar为象限角
            //double fangweijiao = 0;
            //double deltaX = x2 - x1;
            //double deltaY = y2 - y1;
            //double sitar = Math.Atan(deltaY / deltaX);
            //if (deltaX > 0 && deltaY > 0)//一
            //{
            //    fangweijiao = sitar;
            //}
            //else if (deltaX < 0 && deltaY > 0)//二
            //{
            //    fangweijiao = Math.PI - sitar;
            //}
            //else if (deltaX < 0 && deltaY < 0)//三
            //{
            //    fangweijiao = sitar + Math.PI;
            //}
            //else if (deltaX < 0 && deltaY > 0)//四
            //{
            //    fangweijiao = 2 * Math.PI - sitar;
            //}
            //else if (deltaX == 0 && deltaY > 0)
            //{
            //    fangweijiao = Math.PI / 2;
            //}
            //else
            //{
            //    fangweijiao = Math.PI * 3 / 2;
            //}
            //do
            //{
            //    if (fangweijiao > 2 * Math.PI)
            //    { fangweijiao -= 2 * Math.PI; }
            //    else if (fangweijiao < 0)
            //    { fangweijiao += 2 * Math.PI; }
            //} while (fangweijiao < 2 * Math.PI && fangweijiao > 0);
            //return fangweijiao;//弧度
            #endregion
        }
        #endregion
        #region 转角
        /// <summary>
        /// 
        /// </summary>
        /// <param name="zhuan"></param>
        /// <returns></returns>
        public double JulgeZhuan(double zhuan)
        {
            double a = 0;
            if (zhuan >= 0 && zhuan < Math.PI || zhuan > -Math.PI && zhuan <= 0)
            { a = zhuan; }
            if (zhuan >= Math.PI && zhuan <= 2 * Math.PI)
            { a = zhuan - 2 * Math.PI; }
            if (zhuan < -Math.PI && zhuan >= -2 * Math.PI)
            { a = zhuan + 2 * Math.PI; }
            return a;
        }
        #endregion
        #region 圆曲线1
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ZY"></param>
        /// <param name="licheng"></param>
        /// <param name="dianhao"></param>
        /// <param name="R"></param>
        /// <param name="a"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public Point1 yuanquxian1(Point1 ZY, double licheng, string dianhao, double R, double a, double k)
        {
            Point1 f = new Point1();
            double Li = licheng - ZY._licheng;
            double jiao = Li /R;
            double xi = R * Math.Sin(jiao);
            double yi = R * (1 - Math.Cos(jiao));
            f._name = dianhao;
            f._X = ZY._X + xi * Math.Cos(a) - k * yi * Math.Sin(a);
            f._Y = ZY._Y + yi * Math.Sin(a) - k * yi * Math.Cos(a);
            f._licheng = licheng;
            return f;
        }
        #endregion
        #region 圆曲线2
        /// <summary>
        /// 
        /// </summary>
        /// <param name="YZ"></param>
        /// <param name="licheng"></param>
        /// <param name="dianhao"></param>
        /// <param name="R"></param>
        /// <param name="a"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public Point1 yuanquxian2(Point1 YZ, double licheng, string dianhao, double R, double a, double k)
        {
            Point1 f = new Point1();
            double Li = YZ._licheng - licheng;
            double jiao = licheng / Math.PI;
            double xi = R * Math.Sin(jiao);
            double yi = R * (1 - Math.Cos(jiao));
            f._name = dianhao;
            f._X = YZ._X + xi * Math.Cos(a) + k * yi * Math.Sin(a);
            f._Y = YZ._Y + xi * Math.Sin(a) - k * yi * Math.Cos(a);
            f._licheng = licheng;
            return f;
        }
        #endregion
        #region 缓和曲线1
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ZH"></param>
        /// <param name="licheng"></param>
        /// <param name="dianhao"></param>
        /// <param name="R"></param>
        /// <param name="Ls"></param>
        /// <param name="a"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public Point1 huanquxian1(Point1 ZH, double licheng, string dianhao, double R, double Ls, double a, double k)
        {
            Point1 f = new Point1();
            double Li = licheng - ZH._licheng;
            double x1 = Li - Math.Pow(Li, 5) / (40 * R * R * Ls * Ls);
            double y1 = Li * Li * Li / (6 * R * Ls);

            f._name = dianhao;
            f._X = ZH._X + x1 * Math.Cos(a) - k * y1 * Math.Sin(a);
            f._Y = ZH._Y + x1 * Math.Sin(a) + k * y1 * Math.Cos(a);
            f._licheng = licheng;
            return f;
        }//缓和曲线计算ZH-HY坐标
        #endregion
        #region 缓和曲线2
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ZH"></param>
        /// <param name="licheng"></param>
        /// <param name="dianhao"></param>
        /// <param name="R"></param>
        /// <param name="B0"></param>
        /// <param name="m"></param>
        /// <param name="P"></param>
        /// <param name="Ls"></param>
        /// <param name="a"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public Point1 huanquxian2(Point1 ZH, double licheng, string dianhao, double R, double B0, double m, double P, double Ls, double a, double k)
        {
            Point1 f = new Point1();
            double Li = licheng - ZH._licheng;

            double jiao = B0 + (Li - Ls) / R;
            double x1 = m + R * Math.Sin(jiao);
            double y1 = P + R * (1 - Math.Cos(jiao));

            f._name = dianhao;
            f._X = ZH._X + x1 * Math.Cos(a) - k * y1 * Math.Sin(a);
            f._Y = ZH._Y + x1 * Math.Sin(a) + k * y1 * Math.Cos(a);
            f._licheng = licheng;
            return f;
        }//缓和曲线计算HY-YH坐标
        #endregion
        #region 缓和曲线3
        /// <summary>
        /// 
        /// </summary>
        /// <param name="HZ"></param>
        /// <param name="licheng"></param>
        /// <param name="dianhao"></param>
        /// <param name="R"></param>
        /// <param name="Ls"></param>
        /// <param name="a"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public Point1 huanquxian3(Point1 HZ, double licheng, string dianhao, double R, double Ls, double a, double k)
        {
            Point1 f = new Point1();
            double Li = HZ._licheng - licheng;
            double x1 = Li - Math.Pow(Li, 5) / (40 * R * R * Ls * Ls);
            double y1 = Li * Li * Li / (6 * R * Ls);

            f._name = dianhao;
            f._X = HZ._X + x1 * Math.Cos(a) + k * y1 * Math.Sin(a);
            f._Y = HZ._Y + x1 * Math.Sin(a) - k * y1 * Math.Cos(a);
            f._licheng = licheng;
            return f;
        }//缓和曲线计算YH-HZ坐标
        #endregion
        #region 弧度转度分秒
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hudu"></param>
        /// <returns></returns>
        public double hudutodms(double hudu)
        {
            double d, m, s;
            int i = 1;
            if (hudu < 0)
            {
                i = -1;
                hudu = Math.Abs(hudu);
            }
            double du = hudu * 180 / Math.PI;
            d = Math.Floor(du);
            m = Math.Floor((du - d) * 60);
            s = (((du - d) * 60 - m) * 60);
            return Math.Round(i * (d + m / 100 + s / 10000), 10);
        }
        #endregion
        #region 度分秒转化为dd mm ss.ssss 输出
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dms"></param>
        /// <returns></returns>
        public string outputDDmmss(double dms)
        {
            double d, m, s;
            int i = 1;
            if (dms < 0)
            {
                i = -1;
                dms = Math.Abs(dms);
            }
            d = Math.Floor(dms);
            m = Math.Floor((dms - d) * 60);
            s = Math.Round((((dms - d) * 60 - m) * 60), 4);//保留为ss.ssss四位小数
            return i * d + "°" + m + "′" + s + "″";
        }
        #endregion
    }
}
