﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 构建规则格网_GRID_进行体积计算
{
    public class Point1//用来存储带点号的三维点
    {
        public string PointName;//类的成员
        public double X;
        public double Y;
        public double H;
        public double angle;//存储和基点的夹角
    }
    public class Point2//用来存储带点号的三维点
    {
        public string dianhao;//类的成员
        public double X;
        public double Y;
        public double H;
        public int NW;//存储单边交点个数
        public double Vi;//格网体积
    }
    class Method
    {
        #region 求两点之间的距离
        /// <summary>
        /// 求两点之间的距离
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        /// <param name="y1"></param>
        /// <param name="y2"></param>
        /// <returns></returns>
        public static double D(double x1, double y1, double x2, double y2)
        {
            double d = Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
            return d;
        }
        #endregion
        #region 3.1反距离加权法
        /// <summary>
        /// 3.1反距离加权法
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="r"></param>
        /// <param name="M"></param>
        /// <returns></returns>
        public static double GaoCheng(double x, double y, double r, List<Point1> M)
        {
            double d = 0, H;
            List<double> hi = new List<double>();
            List<double> di = new List<double>();
            for (int i = 0; i < M.Count; i++)
            {
                d = D(x, y, M[i].X, M[i].Y);
                if (d <= r)
                {
                    hi.Add(M[i].H / d);
                    di.Add(1 / d);
                }
            }
            H = (hi.Sum() / di.Sum());
            return (double)H;
        }
        #endregion
    }
}
