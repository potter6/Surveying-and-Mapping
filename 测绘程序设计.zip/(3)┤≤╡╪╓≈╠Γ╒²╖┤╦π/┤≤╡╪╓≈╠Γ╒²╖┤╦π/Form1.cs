﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大地主题正反算
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region 变量定义
        Bitmap image;                           //图像的输出
        double a, b, f, e1, e2;                 //基本椭球参数
        List<double> B1 = new List<double>();   //经度1
        List<double> B2 = new List<double>();   //经度2
        List<double> L1 = new List<double>();   //纬度1
        List<double> L2 = new List<double>();   //纬度2
        List<double> A12 = new List<double>();  //方位角起到终
        List<double> A21 = new List<double>();  //方位角终到起
        List<double> S = new List<double>();    //大地线长
        int zf;                                 //保存正算还是反算的信息
        #endregion
        #region 变量初始化
        public void Initialize()
        {
            B1.Clear();
            B2.Clear();
            L1.Clear();
            L2.Clear();
            A12.Clear();
            A21.Clear();
            S.Clear();
            try
            {
                a = Convert.ToDouble(txt_a.Text.Replace(" ", ""));
                f = 1 / Convert.ToDouble(txt_f.Text.Replace(" ", ""));
            }
            catch
            {
                MessageBox.Show("请输入正确的椭球数据");
            }
            #region 椭球基本参数计算
            b = a * (1 - f);
            e1 = (a * a - b * b) / (a * a);//e^2
            e2 = (a * a - b * b) / (b * b);//(e')^2
            #endregion
        }
        #endregion

        Calculate Cal = new Calculate();

        private void 正算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zf = 1;
            Initialize();
            DGV.AllowUserToAddRows = false;
            #region 初始化报告
            richTextBox1.Text = "**************************************************\n";
            richTextBox1.Text += "                  大地主题正算\n";
            richTextBox1.Text += "**************************************************\n";
            richTextBox1.Text += "----------------------统计数据---------------------\n";
            richTextBox1.Text += "计算点对总数:   " + DGV.Rows.Count + "\n";
            richTextBox1.Text += "椭球长半轴：  " + a + "\n";
            richTextBox1.Text += "椭球扁率：  " + f + "\n\n";
            richTextBox1.Text += "----------------------过程数据---------------------\n";
            #endregion
            #region 数据导入
            try
            {
                for (int i = 0; i < DGV.Rows.Count; i++)
                {
                    B1.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[1].Value)));//(-90~90)
                    L1.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[2].Value)));//(0~360)
                    A12.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[3].Value)));//(0~360)
                    S.Add(Convert.ToDouble(DGV.Rows[i].Cells[4].Value));
                }
            }
            catch
            {
                MessageBox.Show("请输入正确的数据！");
                return;
            }
            #endregion
            #region 正算
            for (int i = 0; i < DGV.Rows.Count; i++)
            {
                richTextBox1.Text += "-----\n第" + (i + 1) + "个点对 " + DGV.Rows[i].Cells[0].Value + DGV.Rows[i].Cells[5].Value + "\n";
                #region 计算归化纬度辅助函数
                double sin_u1, cos_u1, sin_u2, sin_m, cos_m, cot_M, M, tan_l, l, gl;//球面元素变量
                double W1 = Math.Sqrt(1 - e1 * Math.Sin(B1[i]) * Math.Sin(B1[i]));//W1
                sin_u1 = Math.Sin(B1[i]) * Math.Sqrt(1 - e1) / W1;//sinu1
                cos_u1 = Math.Cos(B1[i]) / W1;//cosu1

                #endregion
                #region 计算辅助函数值
                sin_m = cos_u1 * Math.Sin(A12[i]);//sinA0 
                cos_m = Math.Sqrt(1 - sin_m * sin_m);//cosA0
                cot_M = (cos_u1 * Math.Cos(A12[i])) / sin_u1;//cotσ1 
                M = Math.Atan(1 / cot_M);

                #endregion
                #region 计算系数A，B，C及α，β，γ的值
                double k2, k4, k6, af, bf, cf, d0, d1, ds; //定义迭代变量，求边长归化量
                k2 = e2 * cos_m * cos_m;
                k4 = k2 * k2;
                k6 = k2 * k2 * k2;
                af = (1 - k2 / 4 + (7 * k4) / 64 - (15 * k6) / 256) / b;//A
                bf = k2 / 4 - (7 * k4) / 8 + (37 * k6) / 512;//B
                cf = (k4 - k6) / 128;//C

                double kk2, kk4, e14, e16, aaf, bbf, ccf;//定义球面计算变量
                kk2 = e1 * cos_m * cos_m;
                kk4 = kk2 * kk2;
                e14 = e1 * e1;
                e16 = e1 * e1 * e1;
                aaf = (e1 / 2 + e14 / 8 + e16 / 16) - e1 * (1 + e1) * kk2 / 16 + 3 * e1 * kk4 / 128;
                bbf = e1 * (1 + e1) * kk2 / 16 - e1 * kk4 / 32;
                ccf = e1 * kk4 / 256;

                #endregion
                #region 计算球面长度            
                d0 = af * S[i];//迭代初值σ0
                int count = 0;
                do
                {
                    d1 = af * S[i] + bf * Math.Sin(d0) * Math.Cos(2 * M + d0) + cf * Math.Sin(2 * d0) * Math.Cos(4 * M + 2 * d0);//σ
                    ds = Math.Abs(d1 - d0);
                    d0 = d1;
                    count++;
                }
                while (ds * 180 / Math.PI * 3600 > Math.Pow(10, -10));//限差0.00001秒(不太清楚10 -10是啥意思)
                MessageBox.Show($"第{i + 1}对\n迭代次数为 {count}");
                #endregion
                #region 计算经差改正数
                //经差改正数
                gl = sin_m * (aaf * d1 + bbf * Math.Sin(d1) * Math.Cos(2 * M + d1) + ccf * Math.Sin(2 * d1) * Math.Cos(4 * M + 2 * d1));

                #endregion
                #region 计算终点大地坐标及大地方位角
                sin_u2 = sin_u1 * Math.Cos(d1) + cos_u1 * Math.Cos(A12[i]) * Math.Sin(d1);
                B2.Add(Math.Atan(sin_u2 / (Math.Sqrt(1 - e1) * Math.Sqrt(1 - sin_u2 * sin_u2))));
                tan_l = Math.Sin(A12[i]) * Math.Sin(d1) / (cos_u1 * Math.Cos(d1) - sin_u1 * Math.Sin(d1) * Math.Cos(A12[i]));
                l = Math.Atan(tan_l);
                if (Math.Sin(A12[i]) > 0)
                {
                    if (tan_l > 0)
                    { l = Math.Abs(l); }
                    else
                    { l = Math.PI - Math.Abs(l); }
                }
                else
                {
                    if (tan_l < 0)
                    { l = -Math.Abs(l); }
                    else
                    { l = Math.Abs(l) - Math.PI; }
                }
                L2.Add(L1[i] + l - gl);
                double tan_a21, a21;
                tan_a21 = cos_u1 * Math.Sin(A12[i]) / (cos_u1 * Math.Cos(d1) * Math.Cos(A12[i]) - sin_u1 * Math.Sin(d1));
                a21 = Math.Atan(tan_a21);

                if (Math.Sin(A12[i]) < 0)
                {
                    if (tan_a21 > 0)
                    { a21 = Math.Abs(a21); }
                    else
                    { a21 = Math.PI - Math.Abs(a21); }
                }
                else
                {
                    if (tan_a21 > 0)
                    { a21 = Math.PI + Math.Abs(a21); }
                    else
                    { a21 = Math.PI * 2 - Math.Abs(a21); }
                }
                A21.Add(a21);
                #endregion
                #region 数据导出
                DGV.Rows[i].Cells[6].Value = Cal.HuduOutPutDms(B2[i]);//0.1''
                DGV.Rows[i].Cells[7].Value = Cal.HuduOutPutDms(L2[i]);
                DGV.Rows[i].Cells[8].Value = Cal.HuduOutPutDms(A21[i]);
                #endregion
                richTextBox1.Text += "1.计算起点的归化纬度\n";
                richTextBox1.Text += "\tW1    :" + string.Format("{0,14}", Math.Round(W1, 3)) + "\n";
                richTextBox1.Text += "\tSin_u1:" + string.Format("{0,14}", Math.Round(sin_u1, 3)) + "\n";
                richTextBox1.Text += "\tCos_u1:" + string.Format("{0,14}", Math.Round(cos_u1, 3)) + "\n";
                richTextBox1.Text += "2.计算辅助函数值\n";
                richTextBox1.Text += "\tSin_A0:" + string.Format("{0,14}", Math.Round(sin_m, 3)) + "\n";
                richTextBox1.Text += "\tCot_σ1:" + string.Format("{0,14}", Math.Round(cot_M, 3)) + "\n";
                richTextBox1.Text += "\tσ1:" + string.Format("{0,14}", Cal.Outputdms(Cal.hudutodms(M))) + "\n";
                richTextBox1.Text += "3.计算系数A，B，C及α，β，γ的值\n";
                richTextBox1.Text += "\tA:" + string.Format("{0,10}", Math.Round(af, 3)) + "\n";
                richTextBox1.Text += "\tB:" + string.Format("{0,10}", Math.Round(bf, 3)) + "\n";
                richTextBox1.Text += "\tC:" + string.Format("{0,10}", Math.Round(cf, 3)) + "\n";
                richTextBox1.Text += "\tα:" + string.Format("{0,10}", Math.Round(aaf, 3)) + "\n";
                richTextBox1.Text += "\tβ:" + string.Format("{0,10}", Math.Round(bbf, 3)) + "\n";
                richTextBox1.Text += "\tγ:" + string.Format("{0,10}", Math.Round(ccf, 3)) + "\n";
                richTextBox1.Text += "4.计算球面长度\n";
                richTextBox1.Text += "\tσ:" + string.Format("{0,10}", Math.Round(d0, 3)) + "\n";
                richTextBox1.Text += "5.计算经差改正数\n";
                richTextBox1.Text += "\tδ:" + string.Format("{0,10}", Cal.Outputdms(Cal.hudutodms(gl))) + "\n";
            }//正算的for
            #region 计算报告
            richTextBox1.Text += "----------------------计算结果---------------------\n";
            richTextBox1.Text += "点名\t\t纬度(B)\t\t经度(L)\t\t大地方位角(A)\t大地线长(S)\n";
            for (int i = 0; i < DGV.Rows.Count; i++)
            {
                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[0].Value) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[1].Value))) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[2].Value))) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[3].Value))) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[4].Value) + "\n";

                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[5].Value) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[6].Value) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[7].Value) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[8].Value) + "\t";
                richTextBox1.Text += string.Format("{0,-16}", DGV.Rows[i].Cells[4].Value) + "\n\n";
            }
            #endregion
            #endregion
        }

        private void 反算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zf = -1;
            Initialize();
            DGV.AllowUserToAddRows = false;
            #region 报告初始化
            richTextBox1.Text = "**************************************************\n";
            richTextBox1.Text += "                  大地主题反算\n";
            richTextBox1.Text += "**************************************************\n";
            richTextBox1.Text += "----------------------统计数据---------------------\n";
            richTextBox1.Text += "计算点对总数:   " + DGV.RowCount + "\n";
            richTextBox1.Text += "椭球长半轴：  " + a + "\n";
            richTextBox1.Text += "椭球扁率：  " + f + "\n\n";
            richTextBox1.Text += "----------------------过程数据---------------------\n";
            #endregion
            #region 数据导入
            try
            {
                for (int i = 0; i < DGV.Rows.Count; i++)
                {
                    B1.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[1].Value)));//(-90~90)
                    L1.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[2].Value)));//(0~360)
                    B2.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[4].Value)));//(0~360)
                    L2.Add(Cal.dmstohudu(Convert.ToDouble(DGV.Rows[i].Cells[5].Value)));
                }
            }
            catch
            {
                MessageBox.Show("请输入正确的数据！");
                return;
            }
            #endregion
            #region 反算
            for (int i = 0; i < DGV.Rows.Count; i++)
            {
                richTextBox1.Text += "-----\n第" + (i + 1) + "个点对 " + DGV.Rows[i].Cells[0].Value + DGV.Rows[i].Cells[3].Value + "\n";
                //要用到的变量值
                double u1, u2, a1, a2, b1, b2;//辅助量
                double p, q, l0, l, dl, gl = 0, gl0;//l0为λ;gl为δ=0;gl0
                double a12, sin_d, cos_d, d, M, sin_m, cos_m;
                double e14, e16, aaf, bbf, ccf;//定义球面计算变量
                double k2, k4, k6, af, bf, cf;//定义迭代变量，求边长归化量
                #region 辅助计算
                u1 = Math.Atan(Math.Sqrt(1 - e1) * Math.Tan(B1[i]));//归化纬度
                u2 = Math.Atan(Math.Sqrt(1 - e1) * Math.Tan(B2[i]));
                l = L2[i] - L1[i];//椭球面经差
                a1 = Math.Sin(u1) * Math.Sin(u2);
                a2 = Math.Cos(u1) * Math.Cos(u2);
                b1 = Math.Cos(u1) * Math.Sin(u2);
                b2 = Math.Sin(u1) * Math.Cos(u2);
                l0 = l;//l0为λ 等于 经差l   λ=ι+δ

                #endregion
                #region 计算起点大地方位角
                int count = 0;
                do
                {
                    //逐次趋近法
                    gl0 = gl;//第一次趋近时，取δ=0 gl=0
                    p = Math.Cos(u2) * Math.Sin(l0);//第一次计算时先以椭球面经差代替球面经差
                    q = b1 - b2 * Math.Cos(l0);
                    a12 = Math.Atan(p / q);
                    if (p > 0)
                    {
                        if (q > 0)
                        { a12 = Math.Abs(a12); }
                        else
                        { a12 = Math.PI - Math.Abs(a12); }
                    }
                    else
                    {
                        if (q < 0)
                        { a12 = Math.PI + Math.Abs(a12); }
                        else
                        { a12 = Math.PI * 2 - Math.Abs(a12); }
                    }

                    sin_d = p * Math.Sin(a12) + q * Math.Cos(a12);//Sinσ
                    cos_d = a1 + a2 * Math.Cos(l0);//Cosσ
                    d = Math.Atan(sin_d / cos_d);//σ
                    if (cos_d > 0)//Cosσ
                    { d = Math.Abs(d); }
                    else
                    { d = Math.PI - Math.Abs(d); }
                    //|A1|->A12 |σ|->l0
                    sin_m = Math.Cos(u1) * Math.Sin(a12);//SinA0=Cosu1*SinA1
                    cos_m = Math.Sqrt(1 - sin_m * sin_m);//CosA0
                    M = Math.Atan(Math.Tan(u1) / Math.Cos(a12));//M->σ1

                    e14 = e1 * e1;//四次方
                    e16 = e1 * e1 * e1;//六次方
                    aaf = (e1 / 2 + e14 / 8 + e16 / 16) - (e14 + e16) / 16 * cos_m * cos_m - 3 * e16 / 128 * Math.Pow(cos_m, 4);//α
                    bbf = (e14 + e16) / 16 * cos_m * cos_m - e16 / 32 * Math.Pow(cos_m, 4);//β
                    ccf = (e16 / 256) * Math.Pow(cos_m, 4);//γ     M->σ1 d->σ

                    gl = (aaf * d + bbf * Math.Cos(2 * M + d) * Math.Sin(d) + ccf * Math.Sin(2 * d) * Math.Cos(4 * M + 2 * d)) * sin_m;//δ
                    l0 = l + gl;//用求得的δ计算λ1=ι+δ
                    dl = Math.Abs(gl - gl0);//两次计算的σ的差的绝对值
                    //MessageBox.Show(Cal.hudutodms(a12).ToString());
                    count++;
                } while (dl * 180 / Math.PI * 3600 > Math.Pow(10, -10));

                MessageBox.Show($"第{i + 1}对\n迭代次数为 {count}");
                A12.Add(a12);//导入a12

                #endregion
                #region 计算大地线长度
                k2 = e2 * cos_m * cos_m;//k^2
                k4 = k2 * k2;//k^4
                k6 = k2 * k2 * k2;//k^6
                af = (1 - (k2) / 4 + (7 * k4) / 64 - (15 * k6) / 256) / b;//A
                bf = k2 / 4 - k4 / 8 + (37 * k6) / 512;//B
                cf = k4 / 128 - k6 / 128;//C
                double s = (d - bf * Math.Sin(d) * Math.Cos(2 * M + d) - cf * Math.Sin(2 * d) * Math.Cos(4 * M + 2 * d)) / af;
                //MessageBox.Show(s.ToString());
                S.Add(s);//大地线长度S

                #endregion
                #region 计算反方位角
                double a21;
                a21 = Math.Atan(Math.Cos(u1) * Math.Sin(l0) / (b1 * Math.Cos(l0) - b2));
                if (a21 < 0)
                { a21 = a21 + Math.PI * 2; }
                else if (a21 > Math.PI * 2)
                { a21 = a21 - Math.PI * 2; }
                if (a12 < Math.PI && a21 < Math.PI)
                { a21 = a21 + Math.PI; }
                if (a12 > Math.PI && a21 > Math.PI)
                { a21 = a21 - Math.PI; }
                //MessageBox.Show(Cal.hudutodms(a21).ToString());
                A21.Add(a21);

                richTextBox1.Text += "1.辅助计算\n\t经差:" + string.Format("{0,10}", Math.Round(l, 3)) + "\n";
                richTextBox1.Text += "2.计算起点大地方位角\n";
                richTextBox1.Text += "\t大地方位角A1:" + string.Format("{0,10}", Cal.Outputdms(Cal.hudutodms(a12))) + "\n";
                richTextBox1.Text += "\t经差:       " + string.Format("{0,14}", Cal.Outputdms(Cal.hudutodms(l0))) + "\n";
                //需要输出格式为dd°mm′ss.ssss″的格式 后同                
                richTextBox1.Text += "3.计算大地线长度\n\t大地线长度S:" + string.Format("{0,14}", Math.Round(s, 3)) + "\n";
                richTextBox1.Text += "4.计算反方位角\n";
                richTextBox1.Text += "\t反方位角A2:" + string.Format("{0,14}", Cal.HuduOutPutDms(a21)) + "\n";
                #endregion
                #region 数据导出
                DGV.Rows[i].Cells[6].Value = Cal.HuduOutPutDms(A12[i]);//0.1''
                DGV.Rows[i].Cells[7].Value = Cal.HuduOutPutDms(A21[i]);
                DGV.Rows[i].Cells[8].Value = Math.Round(S[i], 3);
                #endregion
            }//for (int i = 0; i < DGV.Rows.Count; i++)
            #endregion
            #region 计算报告
            richTextBox1.Text += "----------------------计算结果---------------------\n";
            richTextBox1.Text += "点名\t\t纬度(B)\t\t经度(L)\t\t大地方位角(A)\t大地线长(S)\n";
            for (int i = 0; i < DGV.Rows.Count; i++)
            {
                richTextBox1.Text += string.Format("{0, -16}", DGV.Rows[i].Cells[0].Value) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[1].Value))) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[2].Value))) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", DGV.Rows[i].Cells[6].Value) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", DGV.Rows[i].Cells[8].Value) + "\n";

                richTextBox1.Text += string.Format("{0, -16}", DGV.Rows[i].Cells[3].Value) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[4].Value))) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", Cal.Outputdms(Convert.ToDouble(DGV.Rows[i].Cells[5].Value))) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", DGV.Rows[i].Cells[7].Value) + "\t";
                richTextBox1.Text += string.Format("{0, -16}", DGV.Rows[i].Cells[8].Value) + "\n\n";
            }
            #endregion
        }

        private void 数据保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存报告为txt";
                save.Filter = "txt文件|*.txt";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    using (var sw = new StreamWriter(save.FileName))
                    {
                        sw.Write(richTextBox1.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[1];
            try
            {
                double xmax, ymax, xmin, ymin;
                if (B1.Max() > B2.Max())
                { xmax = Cal.hudutodms(B1.Max()) * 100; }//坐标放大100倍
                else
                { xmax = Cal.hudutodms(B2.Max()) * 100; }
                if (B1.Min() > B2.Min())
                { xmin = Cal.hudutodms(B2.Min()) * 100; }
                else
                { xmin = Cal.hudutodms(B1.Min()) * 100; }
                if (L1.Max() > L2.Max())
                { ymax = Cal.hudutodms(L1.Max()) * 100; }
                else
                { ymax = Cal.hudutodms(L2.Max()) * 100; }
                if (L1.Min() > L2.Min())
                { ymin = Cal.hudutodms(L2.Min()) * 100; }
                else
                { ymin = Cal.hudutodms(L1.Min()) * 100; }
                //MessageBox.Show(xmax.ToString());
                Pen p = new Pen(Color.Black, 10f);//定义画笔
                SolidBrush brush = new SolidBrush(Color.Red);//定义填充
                int width = (int)(ymax - ymin + 400);//图幅长
                int heigth = (int)(xmax - xmin + 400);//图幅宽
                //MessageBox.Show(width.ToString() + "\n" + Height.ToString());
                image = new Bitmap(width, heigth);
                Graphics g = Graphics.FromImage(image);
                g.Clear(Color.White);
                #region 绘制注记，点
                for (int i = 0; i < B1.Count; i++)
                {
                    //MessageBox.Show((Cal.hudutodms(L1[i]) * 100 - ymin + 100).ToString());
                    g.FillEllipse(brush, (float)(Cal.hudutodms(L1[i]) * 100 - ymin + 100) - 50f, -(float)(Cal.hudutodms(B1[i]) * 100 - xmax - 100) - 50f, 100, 100);
                    g.FillEllipse(brush, (float)(Cal.hudutodms(L2[i]) * 100 - ymin + 100) - 50f, -(float)(Cal.hudutodms(B2[i]) * 100 - xmax - 100) - 50f, 100, 100);
                    g.DrawString(DGV.Rows[i].Cells[0].Value.ToString(), new Font("宋体", 150), Brushes.Blue, (float)(Cal.hudutodms(L1[i]) * 100 - ymin + 100) - 2.5f, -(float)(Cal.hudutodms(B1[i]) * 100 - xmax - 100) - 2.5f);//起点
                    if (zf == 1)
                    {
                        g.DrawString(DGV.Rows[i].Cells[5].Value.ToString(), new Font("宋体", 150), Brushes.Blue, (float)(Cal.hudutodms(L2[i]) * 100 - ymin + 100) - 2.5f, -(float)(Cal.hudutodms(B2[i]) * 100 - xmax - 100) - 2.5f);//终点
                    }
                    else
                    {
                        g.DrawString(DGV.Rows[i].Cells[3].Value.ToString(), new Font("宋体", 150), Brushes.Blue, (float)(Cal.hudutodms(L2[i]) * 100 - ymin + 100) - 2.5f, -(float)(Cal.hudutodms(B2[i]) * 100 - xmax - 100) - 2.5f);//终点
                    }
                    g.DrawLine(p, (float)(Cal.hudutodms(L1[i]) * 100 - ymin + 100), -(float)(Cal.hudutodms(B1[i]) * 100 - xmax - 100), (float)(Cal.hudutodms(L2[i]) * 100 - ymin + 100), -(float)(Cal.hudutodms(B2[i]) * 100 - xmax - 100));
                }
                #endregion
                MessageBox.Show("绘制成功！");
                pictureBox1.Image = image;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void 绘图保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存图形为Jpg文件";
                save.Filter = "Jpg文件|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image.Save(save.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void 正算打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            DGV.Rows.Clear();
            正算输入ToolStripMenuItem_Click(sender, e);

            open.Title = "正算";
            open.Filter = "txt文件|*.txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                using (var sr = new StreamReader(open.FileName, Encoding.Default))
                {
                    string[] str = sr.ReadLine().Split(',');
                    txt_a.Text = str[0];
                    txt_f.Text = str[1];
                    int i = 0;
                    while (!sr.EndOfStream)
                    {
                        DGV.Rows.Add();
                        str = sr.ReadLine().Split(',');
                        for (int j = 0; j < str.Length; j++)
                        {
                            DGV.Rows[i].Cells[j].Value = str[j];
                        }
                        i++;
                    }
                }
            }
        }

        private void 反算打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            DGV.Rows.Clear();
            反算输入ToolStripMenuItem_Click(sender, e);

            open.Title = "反算";
            open.Filter = "txt文件|*.txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                using (var sr = new StreamReader(open.FileName, Encoding.Default))
                {
                    string[] str = sr.ReadLine().Split(',');
                    txt_a.Text = str[0];
                    txt_f.Text = str[1];
                    int i = 0;
                    while (!sr.EndOfStream)
                    {
                        DGV.Rows.Add();
                        str = sr.ReadLine().Split(',');
                        for (int j = 0; j < str.Length; j++)
                        {
                            DGV.Rows[i].Cells[j].Value = str[j];
                        }
                        i++;
                    }
                }
            }
        }

        private void 正算输入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DGV.ColumnCount = 9;
            DGV.Columns[0].Name = "起点";
            DGV.Columns[1].Name = "B1";
            DGV.Columns[2].Name = "L1";
            DGV.Columns[3].Name = "A1";
            DGV.Columns[4].Name = "S";
            DGV.Columns[5].Name = "终点";
            DGV.Columns[6].Name = "B2";
            DGV.Columns[7].Name = "L2";
            DGV.Columns[8].Name = "A2";

            DGV.AllowUserToAddRows = true;
        }

        private void 反算输入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DGV.ColumnCount = 9;
            DGV.Columns[0].Name = "起点";
            DGV.Columns[1].Name = "B1";
            DGV.Columns[2].Name = "L1";
            DGV.Columns[3].Name = "终点";
            DGV.Columns[4].Name = "B2";
            DGV.Columns[5].Name = "L2";
            DGV.Columns[6].Name = "A1";
            DGV.Columns[7].Name = "A2";
            DGV.Columns[8].Name = "S";

            DGV.AllowUserToAddRows = true;
        }

        #region 功能组件
        OpenFileDialog open = new OpenFileDialog();
        SaveFileDialog save = new SaveFileDialog();
        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
            Initialize();
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("大地主题正反算");
        }
        #region 时间控件
        private void Form1_Load(object sender, EventArgs e)
        {
            DGV.AllowUserToAddRows = false;

            toolStripStatusLabel3.Text = DateTime.Now.ToString();
            timer1.Enabled = true;
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
        }
        #endregion
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void 图形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[1];
        }

        private void 报告ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[2];
        }

        private void Bigger_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }
        }

        private void Smaller_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Height > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }
        #endregion
    }//class form
}
