﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 纵横断面计算
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region 打开和保存
        OpenFileDialog open = new OpenFileDialog();
        SaveFileDialog save = new SaveFileDialog();
        #endregion
        #region 三张图bitmap
        Bitmap image1;//第一张图
        Bitmap image2;//二
        Bitmap image3;//三
        #endregion
        #region 数据变量
        double gaocheng;//设计高程
        int n;//横断面段数
        double[] fangwei;//纵断面方位角和横断面方位角
        double[] licheng;//纵断面长度（里程）
        Point1[] K;//存储关键点
        Point1[] M;//横断面中心点
        List<Point1> point1;//所有散点s
        List<Point1> ZDM;//纵断面的点
        List<Point1> HDM1;//单个横断面内的点
        List<List<Point1>> HDM;//多个横断面内插点信息 相当于把HDM1套在里面 多维
        #endregion

        #region 从txt文件中读取数据到表格
        private void 打开txt数据文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                tabControl1.SelectedTab = tabControl1.TabPages[0];
                DGV.Rows.Clear();
                DGV.AllowUserToAddRows = false;

                #region 将文件数据读取
                open.Title = "打开txt数据文件";
                open.Filter = "(txt文件)|*.txt";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    List<string> _list = new List<string>();
                    string[] str = File.ReadAllLines(open.FileName, Encoding.Default);
                    for (int i = 0; i < str.Length; i++)
                    {
                        _list.Add(str[i]);
                    }
                    #region 进行表格的初始化
                    DGV.RowCount = _list.Count - 2;
                    DGV.ColumnCount = 4;
                    DGV.Columns[0].Name = "点名";
                    DGV.Columns[1].Name = "X坐标(m)";
                    DGV.Columns[2].Name = "Y坐标(m)";
                    DGV.Columns[3].Name = "Z坐标(m)";
                    DGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    DGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                    DGV.ColumnHeadersHeight = 50;
                    #endregion
                    #region 读入设计高程 和 关键点点名
                    txt_gaocheng.Text = _list[0].Split(',')[1];
                    txt_dianming.Text = _list[1];
                    #endregion
                    #region 将数据（点名、X、Y、Z）读入到表格
                    for (int i = 3; i < DGV.RowCount + 2; i++)
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            DGV.Rows[i - 3].Cells[j].Value = _list[i].Split(',')[j].Replace(" ", "");
                        }
                    }
                    DGV.RowCount--;//可能是什么特性？
                    #endregion
                }
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 计算纵断面
        private void 纵断面ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            ZDM = new List<Point1>();//初始化数据

            #region 数据导入
            try
            {
                string[] dian;//纵断面关键点
                dian = txt_dianming.Text.Split(',');
                n = dian.Length - 1;//纵断面段数 关键点的个数减1 
                gaocheng = Convert.ToDouble(txt_gaocheng.Text);
                //point1 = new Point1[DGV.RowCount];//先规定点数组大小
                point1 = new List<Point1>();//先规定点数组的大小
                K = new Point1[dian.Length];
                for (int i = 0; i < DGV.RowCount; i++)
                {
                    Point1 p = new Point1();
                    p.pointName = DGV.Rows[i].Cells[0].Value.ToString();
                    p.X = Convert.ToDouble(DGV.Rows[i].Cells[1].Value.ToString().Replace(" ", ""));
                    p.Y = Convert.ToDouble(DGV.Rows[i].Cells[2].Value.ToString().Replace(" ", ""));
                    p.Z = Convert.ToDouble(DGV.Rows[i].Cells[3].Value.ToString().Replace(" ", ""));
                    point1.Add(p);
                    for (int j = 0; j < dian.Length; j++)
                    {
                        if (point1[i].pointName == dian[j])//寻找关键点并存储
                        {
                            K[j] = new Point1();
                            K[j].pointName = point1[i].pointName;
                            K[j].X = point1[i].X;
                            K[j].Y = point1[i].Y;
                            K[j].Z = point1[i].Z;
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("请输入正确的数据！");
            }
            //MessageBox.Show(K.Length.ToString());
            #endregion
            try
            {
                #region 纵断面内插点平面坐标           
                fangwei = new double[n];//存储纵断面方位角信息
                licheng = new double[n];//存储纵断面里程长度信息
                K[0].licheng = 0;//初始里程为0
                int k = 0;
                for (int i = 0; i < n; i++)//关键点里程
                {
                    //计算纵断面的长度
                    fangwei[i] = Calculate.fangwei(K[i], K[i + 1]);
                    K[i + 1].licheng = K[i].licheng + Calculate.Distance(K[i], K[i + 1]);
                    licheng[i] = K[i + 1].licheng;
                    //计算内插点的平面坐标
                    while (true)
                    {
                        k = k + 10;//纵断面内插间距为10米
                        if (k < licheng[i])//如果内插的下个10米处的点 要比 里程小 
                        {
                            Point1 p1 = new Point1();
                            p1.pointName = "V-" + (k / 10);
                            p1.licheng = k;
                            p1.X = K[i].X + (p1.licheng - k) * Math.Cos(fangwei[i]);
                            p1.Y = K[i].Y + (p1.licheng - k) * Math.Sin(fangwei[i]);
                            ZDM.Add(p1);
                        }
                        else
                        {
                            k = k - 10;//否则减回去
                            break;
                        }
                    }
                }
                //MessageBox.Show(ZDM.Count.ToString());
                #endregion
                #region 纵断面内插点高程
                double d;//定义一个d 来存储ZDM的某个点和 所有散点间的距离
                int dianhao = 0;//用来存储点号的索引
                for (int i = 0; i < ZDM.Count; i++)//对每个内插点都进行计算
                {
                    double dmin1 = 0;
                    double HD = 0, LD = 0;//计算插值点高程
                    for (int q = 0; q < 5; q++)//寻找最近的5个点 最近->次最近->XXXXX->五个中最远
                    {
                        double dmin = 1000000000000;
                        for (int j = 0; j < point1.Count; j++)//遍历所有散点 循环直到找到dmin=d
                        {
                            d = Calculate.Distance(ZDM[i], point1[j]);
                            if (dmin > d && d > dmin1)
                            {
                                dmin = d;
                                dianhao = j;
                            }
                        }
                        dmin1 = dmin;//用中间值记录这个dmin最小的d 到下次循环用上比较 找次最小
                        //MessageBox.Show(dmin.ToString());
                        HD = HD + point1[dianhao].Z / dmin;
                        LD = LD + 1 / dmin;
                    }
                    ZDM[i].Z = HD / LD;
                }
                #endregion
                #region 纵断面面积
                //从尾至头把K[i]插入ZDM
                ZDM.Add(K[n]);
                for (int i = n - 1; i > 0; i--)
                {
                    for (int j = ZDM.Count - 1; j > 0; j--)
                    {
                        if (K[i].licheng > ZDM[j].licheng)
                        {
                            ZDM.Insert(j + 1, K[i]);
                            break;
                        }
                    }
                }
                ZDM.Insert(0, K[0]);
                //MessageBox.Show(ZDM.Count.ToString());
                double S = 0;
                for (int i = 0; i < ZDM.Count - 1; i++)
                {
                    S += ((ZDM[i].Z + ZDM[i + 1].Z - 2 * gaocheng) * 10 / 2);
                }
                #endregion             
                #region 计算报告
                richTextBox1.Text = "纵横断面计算结果\n\n";
                richTextBox1.Text += "纵断面信息\n------------------------------------------------------------\n";
                richTextBox1.Text += "纵断面面积：  " + Math.Round(S, 3) + "\n";
                richTextBox1.Text += "纵断面全长：  " + Math.Round(licheng.Max(), 3) + "\n";
                richTextBox1.Text += "线路主点：\n";
                richTextBox1.Text += "点名    \t里程K(m)    \tX坐标(m)    \tY坐标(m)    \tH坐标(m)\n";
                for (int i = 0; i < ZDM.Count; i++)
                {
                    string str1;
                    string[] str = new string[5];
                    str[0] = string.Format("{0,-8}", ZDM[i].pointName);
                    str[1] = string.Format("{0,-8}", Math.Round(ZDM[i].licheng, 3));
                    str[2] = string.Format("{0,-8}", Math.Round(ZDM[i].X, 3));
                    str[3] = string.Format("{0,-8}", Math.Round(ZDM[i].Y, 3));
                    str[4] = string.Format("{0,-8}", Math.Round(ZDM[i].Z, 3));
                    str1 = string.Join("\t", str);
                    richTextBox1.Text += str1 + "\n\n";
                }
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region 横断面
        private void 横断面ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                HDM = new List<List<Point1>>();
                #region 横断面中心点信息
                M = new Point1[n];
                for (int i = 0; i < n; i++)
                {
                    M[i] = new Point1();
                    M[i].pointName = "M " + (i + 1);
                    M[i].licheng = 25;
                    M[i].X = (K[i].X + K[i + 1].X) / 2;
                    M[i].Y = (K[i].Y + K[i + 1].Y) / 2;

                    fangwei[i] = fangwei[i] - Math.PI / 2;
                    //加或者减pi/2都可以，正向和反向的排列，只影响横断面里点的排列往返
                }
                #endregion 
                //MessageBox.Show(M[0].X.ToString());
                #region 横断面插值坐标
                for (int i = 0; i < n; i++)
                {
                    int k = 0;
                    HDM1 = new List<Point1>();
                    for (int j = -25; j <= 25; j = j + 5)//延伸25米
                    {
                        if (j != 0)
                        {
                            Point1 p = new Point1();
                            p.pointName = "C" + (j / 5);
                            p.licheng = k;
                            p.X = M[i].X + j * Math.Cos(fangwei[i]);
                            p.Y = M[i].Y + j * Math.Sin(fangwei[i]);
                            HDM1.Add(p);
                        }
                        else
                        {
                            HDM1.Add(M[i]);
                        }
                        k = k + 5;
                    }
                    //MessageBox.Show(HDM1[10].X.ToString());
                    HDM.Add(HDM1);
                    //MessageBox.Show(HDM[0][10].X.ToString());
                }
                #endregion
                #region 横断面内插高程
                for (int i = 0; i < n; i++)//n个横断面
                {
                    double d;
                    int dianhao = 0;
                    for (int j = 0; j < HDM[i].Count; j++)//对每个断面的所有内插点都进行遍历
                    {
                        double dmin1 = 0;
                        double HD = 0, LD = 0;//计算插值点高程
                        for (int q = 0; q < 5; q++)//寻找最近的5个点
                        {
                            double dmin = 1000000000000;
                            for (int k = 0; k < point1.Count; k++)//遍历所有散点
                            {
                                d = Calculate.Distance(HDM[i][j], point1[k]);
                                if (dmin > d && d > dmin1)
                                {
                                    dmin = d;
                                    dianhao = k;
                                }
                            }
                            dmin1 = dmin;//存储最小值，次小值，方便排序
                            //MessageBox.Show(dmin.ToString());
                            HD = HD + point1[dianhao].Z / dmin;
                            LD = LD + 1 / dmin;
                        }
                        HDM[i][j].Z = HD / LD;
                    }
                }
                //MessageBox.Show(HDM1[10].X.ToString());
                #endregion
                #region 横断面面积
                double[] S = new double[n];
                for (int i = 0; i < n; i++)//横断面个数 每个循环求每个横断面面积
                {
                    for (int j = 0; j < HDM[i].Count - 1; j++)
                    {
                        S[i] = S[i] + ((HDM[i][j].Z + HDM[i][j + 1].Z - 2 * gaocheng) * 5 / 2);
                    }
                }
                #endregion
                #region 计算报告
                richTextBox1.Text += "横断面信息\n------------------------------------------------------------\n";
                for (int i = 0; i < n; i++)
                {
                    richTextBox1.Text += "横断面： " + (i + 1) + "\n------------------------------\n";
                    richTextBox1.Text += "横断面面积：  " + Math.Round(S[i], 3) + "\n";
                    richTextBox1.Text += "横断面全长：  " + 50 + "\n";
                    richTextBox1.Text += "线路主点：\n";
                    richTextBox1.Text += "点名    \t里程K(m)    \tX坐标(m)    \tY坐标(m)    \tH坐标(m)\n";
                    for (int j = 0; j < HDM[i].Count; j++)
                    {
                        string str1;
                        string[] str = new string[5];
                        str[0] = string.Format("{0,-8}", HDM[i][j].pointName);
                        str[1] = string.Format("{0,-8}", Math.Round(HDM[i][j].licheng, 3));
                        str[2] = string.Format("{0,-8}", Math.Round(HDM[i][j].X, 3));
                        str[3] = string.Format("{0,-8}", Math.Round(HDM[i][j].Y, 3));
                        str[4] = string.Format("{0,-8}", Math.Round(HDM[i][j].Z, 3));
                        str1 = string.Join("\t", str);
                        richTextBox1.Text += str1 + "\n\n";
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region 一键计算
        private void 计算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            纵断面ToolStripMenuItem_Click(sender, e);
            横断面ToolStripMenuItem_Click(sender, e);
        }
        #endregion

        #region 使用计算出的数据进行绘图
        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                tabControl1.SelectedTab = tabControl1.TabPages[1];
                #region 画散点图
                //寻找最大最小X、Y
                double Xmax1 = point1[0].X, Ymax1 = point1[0].Y, Xmin1 = point1[0].X, Ymin1 = point1[0].Y;
                for (int i = 0; i < point1.Count; i++)
                {
                    if (Xmax1 < point1[i].X) { Xmax1 = point1[i].X; }
                    if (Ymax1 < point1[i].Y) { Ymax1 = point1[i].Y; }
                    if (Xmin1 > point1[i].X) { Xmin1 = point1[i].X; }
                    if (Ymin1 > point1[i].Y) { Ymin1 = point1[i].Y; }
                }
                int width = (int)(Ymax1 - Ymin1 + 20) * 30;
                int height = (int)(Xmax1 - Xmin1 + 20) * 30;
                Pen p = new Pen(Color.Black, 2.5f);//画点
                Pen p1 = new Pen(Color.Black, 2);//画线
                SolidBrush redbrush = new SolidBrush(Color.Red);
                SolidBrush yellowbrush = new SolidBrush(Color.Yellow);
                SolidBrush blackbrush = new SolidBrush(Color.Black);
                SolidBrush bluebrush = new SolidBrush(Color.Blue);

                image1 = new Bitmap(width, height);
                Graphics g1 = Graphics.FromImage(image1);
                g1.Clear(Color.White);
                //导入转换后的散点坐标画出所有散点并标注
                Point[] sanPoint = new Point[point1.Count];
                int D = 14;
                for (int i = 0; i < point1.Count; i++)
                {
                    sanPoint[i].X = (int)(point1[i].Y - Ymin1 + 10) * 30;
                    sanPoint[i].Y = -(int)(point1[i].X - Xmax1 - 10) * 30;
                    g1.DrawEllipse(p, sanPoint[i].X - D / 2, sanPoint[i].Y - D / 2, D, D);
                    g1.FillEllipse(redbrush, sanPoint[i].X - D / 2, sanPoint[i].Y - D / 2, D, D);
                    g1.DrawString(point1[i].pointName, new Font("宋体", 15), bluebrush, sanPoint[i]);
                }
                //画坐标轴
                PointF yuandian1 = new PointF(100, height - 100);//原点
                PointF[] Xzhou1 = new PointF[3] { new PointF(width - 100, height - 100), new PointF(width - 150, height - 125), new PointF(width - 150, height - 75) };//X轴
                PointF[] Yzhou1 = new PointF[3] { new PointF(100, 100), new PointF(75, 150), new PointF(125, 150) };//Y轴
                g1.FillPolygon(blackbrush, Xzhou1); g1.FillPolygon(blackbrush, Yzhou1);//箭头
                g1.DrawLine(p1, yuandian1, Xzhou1[0]); g1.DrawLine(p1, yuandian1, Yzhou1[0]);//x，y轴线
                g1.DrawString("X", new Font("宋体", 40), blackbrush, Xzhou1[0].X + 50, Xzhou1[0].Y);//X轴注记
                g1.DrawString("Y", new Font("宋体", 40), blackbrush, Yzhou1[0].Y + 50, Yzhou1[0].Y);//Y轴注记
                                                                                                  //连关键点
                Point[] keyP = new Point[K.Length];
                for (int i = 0; i < K.Length; i++)
                {
                    keyP[i].X = (int)(K[i].Y - Ymin1 + 10) * 30;
                    keyP[i].Y = -(int)(K[i].X - Xmax1 - 10) * 30;
                }
                g1.DrawLines(p1, keyP);
                //横断面中心点的坐标
                Point[] hengP = new Point[M.Length];
                for (int i = 0; i < M.Length; i++)
                {
                    hengP[i].X = (int)(M[i].Y - Ymin1 + 10) * 30;
                    hengP[i].Y = -(int)(M[i].X - Xmax1 - 10) * 30;
                    g1.DrawString(M[i].pointName, new Font("宋体", 15), redbrush, hengP[i]);
                }
                //画横断面连线
                Point[] hengP1 = new Point[HDM[0].Count];
                for (int i = 0; i < hengP1.Length; i++)
                {
                    hengP1[i].X = (int)(HDM[0][i].Y - Ymin1 + 10) * 30;
                    hengP1[i].Y = -(int)(HDM[0][i].X - Xmax1 - 10) * 30;
                }
                //g1.DrawLines(p1, hengP1);
                g1.DrawLine(p1, hengP1[0], hengP1[hengP1.Length - 1]);
                Point[] hengP2 = new Point[HDM[1].Count];
                for (int i = 0; i < hengP2.Length; i++)
                {
                    hengP2[i].X = (int)(HDM[1][i].Y - Ymin1 + 10) * 30;
                    hengP2[i].Y = -(int)(HDM[1][i].X - Xmax1 - 10) * 30;
                }
                //g1.DrawLines(p1, hengP2);
                g1.DrawLine(p1, hengP2[0], hengP2[hengP2.Length - 1]);

                pictureBox1.Image = image1;
                #endregion
                #region 画纵断面图
                double Xmax2 = ZDM[0].Z, Ymax2 = ZDM[0].licheng;
                double Xmin2 = ZDM[0].Z, Ymin2 = ZDM[0].licheng;
                for (int i = 0; i < ZDM.Count; i++)
                {
                    if (Xmax2 < ZDM[i].Z) { Xmax2 = ZDM[i].Z; }
                    if (Xmin2 > ZDM[i].Z) { Xmin2 = ZDM[i].Z; }
                    if (Ymax2 < ZDM[i].licheng) { Ymax2 = ZDM[i].licheng; }
                    if (Ymin2 > ZDM[i].licheng) { Ymin2 = ZDM[i].licheng; }
                }
                int width2 = (int)(Ymax2 - Ymin2 + 10) * 30 + 100;
                int height2 = (int)(Xmax2 - Xmin2 + 10) * 30 + 100;

                image2 = new Bitmap(width2, height2);
                Graphics g2 = Graphics.FromImage(image2);
                g2.Clear(Color.White);
                //纵断面的里程和高程
                PointF[] zongP = new PointF[ZDM.Count + 2];
                for (int i = 0; i < ZDM.Count; i++)
                {
                    zongP[i].X = (int)(ZDM[i].licheng) * 30 + 10;
                    zongP[i].Y = -(int)(ZDM[i].Z - Xmax2) * 30 + 50;
                }
                for (int i = 0; i < ZDM.Count - 1; i++)
                {
                    g2.DrawLine(p1, zongP[i], zongP[i + 1]);
                }
                //画坐标轴
                PointF yuandian2 = new PointF(10, height2 - 15);
                PointF[] Xzhou2 = new PointF[3] { new PointF(10, 20), new PointF(5, 30), new PointF(15, 30) };
                PointF[] Yzhou2 = new PointF[3] { new PointF(width2 - 10, height2 - 15), new PointF(width2 - 25, height2 - 20), new PointF(width2 - 25, height2 - 10) };
                g2.DrawLine(p1, yuandian2, Xzhou2[0]);//X轴
                g2.DrawLine(p1, yuandian2, Yzhou2[0]);//Y轴
                g2.FillPolygon(blackbrush, Xzhou2);//X箭头
                g2.FillPolygon(blackbrush, Yzhou2);//Y箭头
                g2.DrawString("X", new Font("宋体", 40), blackbrush, Xzhou2[0]);//X轴注释
                g2.DrawString("Y", new Font("宋体", 40), blackbrush, Yzhou2[0].X - 100f, Yzhou2[0].Y - 100f);//Y轴注释
                //找到最右远里程点在 Y轴的投影点
                PointF zongFar = new PointF(zongP[ZDM.Count - 1].X, height2 - 15);
                zongP[ZDM.Count] = new PointF(zongFar.X, zongFar.Y);
                zongP[ZDM.Count + 1] = new PointF(yuandian2.X, yuandian2.Y);
                g2.FillPolygon(yellowbrush, zongP);//填充
                //最后画点并注释
                for (int i = 0; i < ZDM.Count; i++)
                {
                    g2.DrawEllipse(p, zongP[i].X - D / 2, zongP[i].Y - D / 2, D, D);
                    g2.DrawString(ZDM[i].pointName, new Font("宋体", 20), redbrush, zongP[i]);
                }

                pictureBox2.Image = image2;
                #endregion
                #region 画横断面图

                image3 = new Bitmap(width, height);
                Graphics g3 = Graphics.FromImage(image3);
                g3.Clear(Color.White);

                pictureBox3.Image = image3;
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 保存报告
        /// <summary>
        /// 保存纵横断面的数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 保存报告为txtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存报告为txt文件";
                save.Filter = "(txt文件)|*.txt";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    using (var sw = new StreamWriter(save.FileName))
                    {
                        sw.Write(richTextBox1.Text);
                    }
                }
                MessageBox.Show("保存文件成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 放大
        private void Bigger_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000 || pictureBox2.Width < 5000 || pictureBox3.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
                pictureBox2.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox2.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
                pictureBox3.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox3.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }
        }
        #endregion
        #region 缩小
        private void Smaller_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 100 || pictureBox2.Width > 100 || pictureBox3.Width > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
                pictureBox2.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox2.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
                pictureBox3.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox3.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }
        #endregion
        #region 退出程序
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion
        #region 保存散点图
        private void 保存1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存散点图";
                save.Filter = "(jpg文件)|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image1.Save(save.FileName);
                }
                MessageBox.Show("保存散点图成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 保存纵断面图
        private void 保存2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存纵断面图";
                save.Filter = "(jpg文件)|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image2.Save(save.FileName);
                }
                MessageBox.Show("保存纵断面图成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 保存横断面图
        private void 保存3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存横断面图图";
                save.Filter = "(jpg文件)|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image3.Save(save.FileName);
                }
                MessageBox.Show("保存横断面图成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 帮助
        private void 帮助ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("纵横断面计算!---potter");
        }
        #endregion
        #region 刷新
        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
        #endregion
        #region 转到tabpage
        private void 数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void 图形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[1];
        }

        private void 报告ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[2];
        }
        #endregion
        #region 时间控件
        private void Form1_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
            timer1.Enabled = true;
            timer1.Interval = 1000;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
        }
        #endregion
    }
}
