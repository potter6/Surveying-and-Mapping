﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 不规则三角网_TIN_进行体积计算
{
    public class Point1//存储点的名、X、Y、Z
    {
        public string PointName;
        public double X;
        public double Y;
        public double Z;
    }

    public class Line//用来存储线 起点到终点的连线
    {
        public Point1 Begin;
        public Point1 End;
    }

    public class sjx//用来存储三角形的三个点
    {
        public Point1 p1;
        public Point1 p2;
        public Point1 p3;
    }

    class Calculate
    {
        #region 三角形外接圆圆心
        public double X0(double x1, double y1, double x2, double y2, double x3, double y3)
        {
            double x0;
            x0 = ((y2 - y1) * (y3 * y3 - y1 * y1 + x3 * x3 - x1 * x1) - (y3 - y1) * (y2 * y2 - y1 * y1 + x2 * x2 - x1 * x1)) / (2 * (x3 - x1) * (y2 - y1) - 2 * (x2 - x1) * (y3 - y1));
            return x0;
        }
        public double Y0(double x1, double y1, double x2, double y2, double x3, double y3)
        {
            double y0;
            y0 = ((x2 - x1) * (x3 * x3 - x1 * x1 + y3 * y3 - y1 * y1) - (x3 - x1) * (x2 * x2 - x1 * x1 + y2 * y2 - y1 * y1)) / (2 * (y3 - y1) * (x2 - x1) - 2 * (y2 - y1) * (x3 - x1));
            return y0;
        }
        #endregion  
        #region 三角形外接圆半径
        public double R(double x0, double y0, double x1, double y1)
        {
            double R;
            R = Math.Sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1));
            return R;
        }
        #endregion
        #region 斜三棱柱计算
        public double SS(sjx san)
        {
            double S;
            S = Math.Abs((san.p2.X - san.p1.X) * (san.p3.Y - san.p1.Y)
                       - (san.p3.X - san.p1.X) * (san.p2.Y - san.p1.Y)) / 2.0;
            #region
            //海伦公式 是等价的
            //double a = Math.Sqrt(Math.Pow(san.p1.X - san.p2.X, 2) + Math.Pow(san.p1.Y - san.p2.Y, 2));
            //double b = Math.Sqrt(Math.Pow(san.p2.X - san.p3.X, 2) + Math.Pow(san.p2.Y - san.p3.Y, 2));
            //double c = Math.Sqrt(Math.Pow(san.p3.X - san.p1.X, 2) + Math.Pow(san.p3.Y - san.p1.Y, 2));
            //double M = (a + b + c) / 2.0;
            //S = Math.Sqrt(M * (M - a) * (M - b) * (M - c));
            #endregion
            return S;
        }
        public double H(sjx san, double gaocheng)
        {
            double H;
            H = (san.p1.Z + san.p2.Z + san.p3.Z) / 3.0 - gaocheng;
            return H;
        }
        #endregion
    }
}
