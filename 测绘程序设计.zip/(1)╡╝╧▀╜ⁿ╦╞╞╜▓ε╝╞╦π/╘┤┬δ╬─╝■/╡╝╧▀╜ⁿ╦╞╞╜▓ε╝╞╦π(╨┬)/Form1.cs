﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 导线近似平差计算_新_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static List<Npoint> _dp = new List<Npoint>();//画图
        #region 定义变量
        int k;//存储转角情况
        double bhc;
        double xbhc;
        double ybhc;
        double xybhc;
        List<string> dianhao;//点号
        List<double> _viewAngles;//观测角 弧度参与计算
        List<double> _Azimuth;//方位角
        List<double> _length;//边长
        List<double> _dx;//X坐标增量
        List<double> _dy;//Y坐标增量
        List<double> _X;//X坐标
        List<double> _Y;//Y坐标
        Bitmap image;
        //Bitmap image;
        #endregion
        //初始化
        public void InitialData()
        {
            dianhao = new List<string>();//点号
            _viewAngles = new List<double>();//观测角 弧度参与计算
            _Azimuth = new List<double>();//方位角
            _length = new List<double>();//边长
            _dx = new List<double>();//X坐标增量
            _dy = new List<double>();//Y坐标增量
            _X = new List<double>();//X坐标
            _Y = new List<double>();//Y坐标
        }

        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DGV.Rows.Clear();
                richTextBox1.Text = "";
                pictureBox1.Image = null;
                tabControl1.SelectedTab = tabControl1.TabPages[0];
                Method.InitialDataGridView(this.DGV);
                Method.ReadFromTxt(this.DGV);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void 计算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                InitialData();
                tabControl1.SelectedTab = tabControl1.TabPages[0];
                DGV.AllowUserToAddRows = false;//这个很重要，否则计算报错
                #region 数据导入
                for (int i = 0; i < DGV.Rows.Count; i = i + 2)//每隔两个导入一个
                {
                    dianhao.Add(DGV.Rows[i].Cells[0].Value.ToString());
                    if (i != 0 && i != DGV.Rows.Count - 2)
                    {
                        _viewAngles.Add(caculate.dmstohudu(DGV.Rows[i].Cells[1].Value.ToString().Replace(" ", "")));
                    }
                    if (i != 0 && i != DGV.Rows.Count - 2 && i != DGV.Rows.Count - 4)
                    {
                        _length.Add(Convert.ToDouble(DGV.Rows[i + 1].Cells[3].Value.ToString().Replace(" ", "")));
                    }
                    if (i == 0 || i == 2 || i == DGV.Rows.Count - 4 || i == DGV.Rows.Count - 2)
                    {
                        _X.Add(Convert.ToDouble(DGV.Rows[i].Cells[6].Value.ToString().Replace(" ", "")));
                        _Y.Add(Convert.ToDouble(DGV.Rows[i].Cells[7].Value.ToString().Replace(" ", "")));
                    }
                }
                //MessageBox.Show(caculate.hudutodms(_viewAngles[0]));
                //MessageBox.Show(_length[0].ToString());
                //MessageBox.Show(_Y[0].ToString());
                #endregion
                #region 判断左右角
                if (rdb_left.Checked)
                {
                    k = 1;
                }
                else
                {
                    k = -1;
                }
                #endregion
                #region 方位角计算
                double n = 0;//存储加减360的信息
                List<double> _Azimuthi = new List<double>();//存储粗略的方位角
                                                            //MessageBox.Show(_X[0].ToString());
                                                            //MessageBox.Show(_Y[0].ToString());
                                                            //MessageBox.Show(_X[1].ToString());
                                                            //MessageBox.Show(_Y[1].ToString());
                double _Azimuth1 = caculate.fangwei(_X[0], _Y[0], _X[1], _Y[1]);
                double _Azimuth2 = caculate.fangwei(_X[2], _Y[2], _X[3], _Y[3]);
                //MessageBox.Show(caculate.hudutodms(_Azimuth1).ToString());

                _Azimuthi.Add(_Azimuth1);
                for (int i = 0; i < _viewAngles.Count; i++)
                {
                    double fangwei = _Azimuthi[i] + k * _viewAngles[i] - k * Math.PI;
                    if (fangwei > Math.PI * 2)
                    {
                        fangwei = fangwei - Math.PI * 2;
                        n = n - Math.PI * 2;
                    }
                    else if (fangwei < 0)
                    {
                        fangwei = fangwei + Math.PI * 2;
                        n = n + Math.PI * 2;
                    }
                    _Azimuthi.Add(fangwei);
                }
                //MessageBox.Show(caculate.hudutodms(_Azimuthi[1]));
                #endregion
                #region 角度近似平差
                bhc = _Azimuth1 + k * _viewAngles.Sum() - k * _viewAngles.Count * Math.PI - _Azimuth2 + n;
                //MessageBox.Show(caculate.hudutos(bhc).ToString());
                if (caculate.hudutos(bhc) > 24 * Math.Sqrt(_viewAngles.Count))
                {
                    MessageBox.Show("角度闭合差超限！");
                }
                else
                {
                    _Azimuth.Add(_Azimuth1);
                    for (int i = 0; i < _viewAngles.Count; i++)
                    {
                        double fangwei;
                        fangwei = _Azimuth[i] + k * (_viewAngles[i] - bhc / _viewAngles.Count) - k * Math.PI;
                        if (fangwei > Math.PI * 2)
                        {
                            fangwei = fangwei - Math.PI * 2;
                        }
                        else if (fangwei < 0)
                        {
                            fangwei = fangwei + Math.PI * 2;
                        }
                        _Azimuth.Add(fangwei);
                    }
                }
                for (int i = 1; i <= _viewAngles.Count; i++)//输出改正后观测角
                {
                    DGV.Rows[i * 2].Cells[1].Value = caculate.hudutodms(_viewAngles[i - 1] - bhc / _viewAngles.Count);
                }
                for (int i = 0; i < _Azimuth.Count; i++)//输出方位角
                {
                    DGV.Rows[i * 2 + 1].Cells[2].Value = caculate.hudutodms(_Azimuth[i]);
                }
                #endregion
                #region 坐标近似平差
                for (int i = 0; i < _length.Count; i++)
                {
                    _dx.Add(_length[i] * Math.Cos(_Azimuth[i + 1]));
                    _dy.Add(_length[i] * Math.Sin(_Azimuth[i + 1]));
                }
                xbhc = _X[1] + _dx.Sum() - _X[2];
                ybhc = _Y[1] + _dy.Sum() - _Y[2];
                xybhc = Math.Sqrt(xbhc * xbhc + ybhc * ybhc);
                if (xybhc / _length.Sum() > (1 / 5000d))//5000d必须加d，要不然算出来是0
                {
                    MessageBox.Show("导线全长相对闭合差超限！");
                }
                //MessageBox.Show(xbhc.ToString());
                //MessageBox.Show(ybhc.ToString());

                for (int i = 1; i <= _dx.Count; i++)//显示的是改正后的量
                {
                    DGV.Rows[i * 2 + 1].Cells[4].Value = Math.Round(_dx[i - 1] - xbhc * _length[i - 1] / _length.Sum(), 4);
                    DGV.Rows[i * 2 + 1].Cells[5].Value = Math.Round(_dy[i - 1] - ybhc * _length[i - 1] / _length.Sum(), 4);
                }
                for (int i = 0; i < _length.Count; i++)
                {
                    _X.Insert(i + 2, _X[i + 1] + _dx[i] - xbhc * _length[i] / _length.Sum());
                    _Y.Insert(i + 2, _Y[i + 1] + _dy[i] - ybhc * _length[i] / _length.Sum());
                    DGV.Rows[i * 2 + 4].Cells[6].Value = Math.Round(_X[i + 2], 4);
                    DGV.Rows[i * 2 + 4].Cells[7].Value = Math.Round(_Y[i + 2], 4);
                }
                DGV.Columns[2].DefaultCellStyle.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Bold);
                DGV.Columns[4].DefaultCellStyle.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Bold);
                DGV.Columns[5].DefaultCellStyle.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Bold);
                DGV.Columns[6].DefaultCellStyle.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Bold);
                DGV.Columns[7].DefaultCellStyle.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Bold);

                DGV.Rows[0].Cells[6].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[0].Cells[7].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[2].Cells[6].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[2].Cells[7].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[DGV.RowCount - 2].Cells[6].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[DGV.RowCount - 2].Cells[7].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[DGV.RowCount - 4].Cells[6].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                DGV.Rows[DGV.RowCount - 4].Cells[7].Style.Font = new Font(DGV.DefaultCellStyle.Font, FontStyle.Regular);
                //↑加粗的为计算出来的数据
                _X.RemoveAt(_X.Count - 2);//x最后计算会多出一个
                _Y.RemoveAt(_Y.Count - 2);
                #endregion
                #region 生成报告
                richTextBox1.Text = "******************************************************\n*******************附和导线近似平差*******************\n\n";
                richTextBox1.Text += "---------------限差要求---------------\n";
                richTextBox1.Text += "角度闭合差限差：" + Math.Round(24 * Math.Sqrt(_viewAngles.Count), 3) + "\n";
                richTextBox1.Text += "导线全长相对闭合差限差" + (1 / 5000d) + "\n\n";
                richTextBox1.Text += "---------------导线基本信息---------------\n";
                richTextBox1.Text += "测站数：" + _viewAngles.Count + "\n";
                richTextBox1.Text += "导线全长" + _length.Sum() + "\n";
                richTextBox1.Text += "角度闭合差：" + caculate.hudutos(bhc) + "″\n";
                richTextBox1.Text += "各站角度改正值：" + caculate.hudutos(bhc / _viewAngles.Count) + "″\n";
                richTextBox1.Text += "X坐标闭合差：" + Math.Round(xbhc, 4) + "\n";
                richTextBox1.Text += "Y坐标闭合差：" + Math.Round(ybhc, 4) + "\n";
                richTextBox1.Text += "导线全长闭合差：" + Math.Round(xybhc / _length.Sum(), 8) + "\n\n";
                richTextBox1.Text += "---------------测站点坐标---------------\n";
                richTextBox1.Text += "测站        \tX坐标       \tY坐标\n";
                for (int i = 0; i < _X.Count; i++)
                {
                    richTextBox1.Text += string.Format("{0,-8}", dianhao[i]) + "\t";
                    richTextBox1.Text += string.Format("{0,-8}", Math.Round(_X[i], 4)) + "\t";
                    richTextBox1.Text += string.Format("{0,-8}", Math.Round(_Y[i], 4)) + "\n";
                }
                richTextBox1.Text += "---------------角度数据---------------\n";
                richTextBox1.Text += "            \t            \t方位角\n";
                richTextBox1.Text += "测站名      \t观测角\n";
                for (int i = 0; i < _Azimuth.Count; i++)
                {
                    richTextBox1.Text += "            \t            \t" + caculate.hudutodms(_Azimuth[i]) + "\n";
                    if (i != _Azimuth.Count - 1)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", dianhao[i]) + "\t";//输出的是没有改正后的观测角
                        richTextBox1.Text += string.Format("{0,-8}", caculate.hudutodms(_viewAngles[i])) + "\n";
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            tabControl1.SelectedTab = tabControl1.TabPages[1];
            Pen p = new Pen(Color.Black, 2.5f);//定义画笔
            Pen p2 = new Pen(Color.Blue, 2);
            SolidBrush brush = new SolidBrush(Color.Black);//定义填充
            int width = (int)(_Y.Max() - _Y.Min() + 200);
            int height = (int)(_X.Max() - _X.Min() + 200);
            MessageBox.Show(width.ToString() + " " + height.ToString());
            image = new Bitmap(width, height);
            Graphics g = Graphics.FromImage(image);
            g.Clear(Color.White);
            PointF[] pf = new PointF[_X.Count];
            #region 绘制线型
            for (int i = 0; i < _X.Count; i++)
            {
                pf[i].X = (float)(_Y[i] - _Y.Min() + 100);
                pf[i].Y = -(float)(_X[i] - _X.Max() - 100);
            }
            g.DrawLines(p, pf);
            #endregion
            #region 绘制注记，点
            for (int i = 0; i < _X.Count; i++)
            {
                g.FillEllipse(brush, pf[i].X - 2.5f, pf[i].Y - 2.5f, 5, 5);
                g.DrawString(dianhao[i], new Font("宋体", 30), Brushes.Red, pf[i].X - 2.5f, pf[i].Y - 2.5f);
            }
            #endregion
            #region 绘制坐标轴
            PointF[] xpt = new PointF[3] { new PointF(50, 35), new PointF(40, 50), new PointF(60, 50) };
            PointF[] ypt = new PointF[3] { new PointF(width - 35, height - 50), new PointF(width - 50, height - 60), new PointF(width - 50, height - 40) };
            g.DrawLine(p, 50, height - 50, 50, 50);//画x轴
            g.DrawLine(p, 50, height - 50, width - 50, height - 50);//画y轴
            g.FillPolygon(brush, xpt);//x轴箭头
            g.FillPolygon(brush, ypt);//y轴箭头
            g.DrawString("X", new Font("宋体", 30), Brushes.Black, 20, 40);
            g.DrawString("Y", new Font("宋体", 30), Brushes.Black, width - 60, height - 40);//注记文字是在点位的右上角绘制
            for (int i = 0; i <= (int)(_X.Max() - _X.Min()); i = i + (int)((_X.Max() - _X.Min()) / 10))
            {
                g.DrawString(((int)(_X.Min() + i)).ToString(), new Font("宋体", 20), Brushes.Black, 0, height - 100 - i);
                g.DrawLine(p, 50, height - 100 - i, 65, height - 100 - i);
            }
            for (int i = 0; i <= (int)(_Y.Max() - _Y.Min()); i = i + (int)((_Y.Max() - _Y.Min()) / 10))
            {
                g.DrawString(((int)(_Y.Min() + i)).ToString(), new Font("宋体", 20), Brushes.Black, 100 + i, height - 40);
                g.DrawLine(p, 100 + i, height - 50, 100 + i, height - 65);
            }
            #endregion
            pictureBox1.Image = (Image)image;


            #region 
            //_dp.Clear();//清除
            //tabControl1.SelectedTab = tabControl1.TabPages[1];
            //for (int i = 0; i < DGV.RowCount; i += 2)//传入所有的点和x，y坐标
            //{
            //    _dp.Add(new Npoint(DGV.Rows[i].Cells[0].Value.ToString(),
            //        Convert.ToSingle(DGV.Rows[i].Cells[6].Value),
            //        Convert.ToSingle(DGV.Rows[i].Cells[7].Value)));
            //}
            //Drawpic draw = new Drawpic();//定义绘图类
            //List<PointF> p = new List<PointF>();
            //List<string> pointName = new List<string>();
            //foreach (var i in Form1._dp)
            //{
            //    p.Add(new PointF((float)i.X, (float)i.Y));
            //    pointName.Add(i.Name);
            //}
            //draw.drawIt(_dp);
            ////draw.DrawLine(p);
            ////draw.DrawPoint(p, pointName);

            //pictureBox1.Image = draw.final();
            #endregion
        }

        private void 数据保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Method.SaveReport(this.richTextBox1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void 绘图保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var save = new SaveFileDialog();
                save.Title = "保存绘图为jpg";
                save.Filter = "(jpg文件)|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image.Save(save.FileName);
                }
                MessageBox.Show("保存绘图成功！");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void 报告ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[2];
        }

        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();//清空窗体中的所有控件
            this.InitializeComponent();//初始化窗体控件
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("导线近似平差计算！");
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Bigger_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }

        }

        private void Smaller_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }
    }
}
