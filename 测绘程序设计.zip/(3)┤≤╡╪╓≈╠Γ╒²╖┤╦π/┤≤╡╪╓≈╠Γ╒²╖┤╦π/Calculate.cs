﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 大地主题正反算
{
    class Calculate
    {
        #region 度分秒转弧度
        /// <summary>
        /// 度分秒转弧度
        /// </summary>
        /// <param name="dms"></param>
        /// <returns></returns>
        public double dmstohudu(double dms)
        {
            double d, m, s;
            int i = 1;
            if (dms < 0)
            {
                i = -1;
                dms = Math.Abs(dms);
            }
            d = Math.Floor(dms);
            m = Math.Floor((dms - d) * 100);
            s = ((dms - d) * 100 - m) * 100;
            return i * (d + m / 60 + s / 3600) * Math.PI / 180;
        }
        #endregion
        #region 弧度转度分秒
        public double hudutodms(double hudu)
        {
            double d, m, s;
            int i = 1;
            if (hudu < 0)
            {
                i = -1;
                hudu = Math.Abs(hudu);
            }
            double du = hudu * 180 / Math.PI;
            d = Math.Floor(du);
            m = Math.Floor((du - d) * 60);
            s = ((du - d) * 60 - m) * 60;
            return Math.Round(i * (d + m / 100 + s / 10000), 10);
        }
        #endregion
        #region 弧度->dd°mm′ss.s″
        public string HuduOutPutDms(double rad)
        {
            double d, m, s;
            int i = 1;
            if (rad < 0)
            {
                i = -1;
                rad = Math.Abs(rad);
            }
            double du = rad * 180 / Math.PI;
            d = Math.Floor(du);
            m = Math.Floor((du - d) * 60);
            s = Math.Round(((du - d) * 60 - m) * 60, 1);
            return i * d + "°" + m + "′" + s + "″";
        }
        #endregion
        #region 将度.分秒按dd°mm′ss.ssss″格式输出
        public string Outputdms(double dms)
        {
            double d, m, s;
            int i = 1;
            if (dms < 0)
            {
                i = -1;
                dms = Math.Abs(dms);
            }
            d = Math.Floor(dms);
            m = Math.Floor((dms - d) * 100);
            s = Math.Round(((dms - d) * 100 - m) * 100, 1);
            return i * d + "°" + m + "′" + s + "″";
        }
        #endregion

    }
}
