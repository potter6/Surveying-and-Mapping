﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 水准路线平差计算
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Calculate calculate = new Calculate();
        float[,] ResourceMatrix;//源矩阵
        Bitmap image;
        string beginPoint;//P51
        string endPoint;//Q48
        float beginH;//已知高程
        float endH;//已知高程
        float bhc;//闭合差
        float[] S = new float[4];//路段长
        float[] H = new float[4];//高差高
        float[] VH = new float[4];//分配后高差高
        float[] V = new float[4];//改正数
        List<float> _1behindD;//Distance
        List<float> _1frontD;
        List<float> _2behindD;
        List<float> _2frontD;
        List<float> _1deltaD;
        List<float> _2deltaD;
        List<float> _deltaD;
        List<float> _totalD;

        List<float> _1behindM;//Middle
        List<float> _1frontM;
        List<float> _2behindM;
        List<float> _2frontM;
        List<float> _behindDeltaM;
        List<float> _frontDeltaM;
        List<float> _1Height;
        List<float> _2Height;
        List<float> _deltaM;
        List<float> _Height;

        //初始化数据
        public void InitialData()
        {
            _1behindD = new List<float>();//distance
            _1frontD = new List<float>();
            _2behindD = new List<float>();
            _2frontD = new List<float>();
            _1deltaD = new List<float>();
            _2deltaD = new List<float>();
            _deltaD = new List<float>();
            _totalD = new List<float>();

            _1behindM = new List<float>();//Middle
            _1frontM = new List<float>();
            _2behindM = new List<float>();
            _2frontM = new List<float>();
            _behindDeltaM = new List<float>();
            _frontDeltaM = new List<float>();
            _1Height = new List<float>();
            _2Height = new List<float>();
            _deltaM = new List<float>();
            _Height = new List<float>();
        }
        //读入txt数据
        private void 文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var OpenTxtFile = new OpenFileDialog();
                OpenTxtFile.Title = "打开txt数据文件";
                OpenTxtFile.Filter = "(txt文件)|*.txt";
                if (OpenTxtFile.ShowDialog() == DialogResult.OK)
                {
                    string path = OpenTxtFile.FileName;
                    using (StreamReader sr = new StreamReader(path))
                    {
                        string[] lines = File.ReadAllLines(path, Encoding.Default);
                        List<string> _list = new List<string>();
                        for (int i = 0; i < lines.Length; i++)
                        {
                            _list.Add(lines[i]);
                        }
                        this.Controls.Clear();
                        this.InitializeComponent();

                        dataGV.RowCount = _list.Count;
                        dataGV.ColumnCount = 20;
                        //dataGV.RowHeadersVisible = false;//把左边的白框给去掉
                        dataGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                        #region 表头
                        dataGV.Columns[0].Name = "后视点名";
                        dataGV.Columns[1].Name = "前视点名";
                        dataGV.Columns[2].Name = "后距1";
                        dataGV.Columns[3].Name = "后距2";
                        dataGV.Columns[4].Name = "前距1";
                        dataGV.Columns[5].Name = "前距2";
                        dataGV.Columns[6].Name = "距离差1";
                        dataGV.Columns[7].Name = "距离差2";
                        dataGV.Columns[8].Name = "距离差d";
                        dataGV.Columns[9].Name = "Σd";
                        dataGV.Columns[10].Name = "后视中丝1";
                        dataGV.Columns[11].Name = "后视中丝2";
                        dataGV.Columns[12].Name = "前视中丝1";
                        dataGV.Columns[13].Name = "前视中丝2";
                        dataGV.Columns[14].Name = "后视中丝差";
                        dataGV.Columns[15].Name = "前视中丝差";
                        dataGV.Columns[16].Name = "高差1";
                        dataGV.Columns[17].Name = "高差2";
                        dataGV.Columns[18].Name = "中丝差";
                        dataGV.Columns[19].Name = "高差";
                        #endregion
                        //给计算结果所在的表格文字加粗
                        for (int i = 6; i < 10; i++)
                        {
                            dataGV.Columns[i].DefaultCellStyle.Font = new Font(dataGV.DefaultCellStyle.Font, FontStyle.Bold);
                            if (i == 9)
                            {
                                for (int j = 14; j < 19; j++)
                                {
                                    dataGV.Columns[j].DefaultCellStyle.Font = new Font(dataGV.DefaultCellStyle.Font, FontStyle.Bold);
                                }
                            }
                        }

                        //后视点名 前视点名
                        for (int i = 0; i < 2; i++)
                        {
                            for (int j = 0; j < dataGV.RowCount - 13; j++)
                            {
                                dataGV.Rows[j].Cells[i].Value = _list[j + 3].Split(',')[i];
                            }
                        }

                        for (int i = 0; i < dataGV.RowCount - 13; i++)
                        {
                            dataGV.Rows[i].Cells[2].Value = _list[i + 3].Split(',')[2];//后视距离1
                            dataGV.Rows[i].Cells[4].Value = _list[i + 3].Split(',')[4];//前1
                            dataGV.Rows[i].Cells[5].Value = _list[i + 3].Split(',')[6];//前2
                            dataGV.Rows[i].Cells[3].Value = _list[i + 3].Split(',')[8];//后2
                        }

                        for (int i = 0; i < dataGV.RowCount - 13; i++)
                        {
                            dataGV.Rows[i].Cells[10].Value = _list[i + 3].Split(',')[3];//后视中丝1
                            dataGV.Rows[i].Cells[12].Value = _list[i + 3].Split(',')[5];//前1
                            dataGV.Rows[i].Cells[13].Value = _list[i + 3].Split(',')[7];//前2
                            dataGV.Rows[i].Cells[11].Value = _list[i + 3].Split(',')[9];//后2
                        }

                        dataGV.RowCount -= 13;
                        //导入起点和终点
                        beginPoint = _list[0].Split(',')[0];
                        beginH = Convert.ToSingle(_list[0].Split(',')[1]);
                        endPoint = _list[1].Split(',')[1];
                        endH = Convert.ToSingle(_list[1].Split(',')[1]);
                        //导入矩阵  24~27
                        ResourceMatrix = new float[4, 4];
                        int k = _list.Count - 9;
                        for (int i = 0; i < 4; i++)
                        {
                            for (int j = 0; j < 4; j++)
                            {
                                ResourceMatrix[i, j] = Convert.ToSingle(_list[k].Split(',')[j]);
                            }
                            k++;
                        }

                        #region test
                        //dataGV.Rows[1].Cells[9].Value = (totalD[0] + deltaD[1]).ToString("0.000");
                        //totalD.Add(Convert.ToSingle(dataGV.Rows[1].Cells[9].Value));

                        //dataGV.Rows[2].Cells[9].Value = (totalD[1] + deltaD[2]).ToString("0.000");
                        //totalD.Add(Convert.ToSingle(dataGV.Rows[2].Cells[9].Value));

                        //dataGV.Rows[3].Cells[9].Value = (totalD[2] + deltaD[3]).ToString("0.000");
                        //totalD.Add(Convert.ToSingle(dataGV.Rows[3].Cells[9].Value));

                        //dataGV.Rows[4].Cells[9].Value = (totalD[3] + deltaD[4]).ToString("0.000");
                        //totalD.Add(Convert.ToSingle(dataGV.Rows[4].Cells[9].Value));

                        //dataGV.Rows[5].Cells[9].Value = (totalD[4] + deltaD[5]).ToString("0.000");
                        //totalD.Add(Convert.ToSingle(dataGV.Rows[5].Cells[9].Value));
                        #endregion
                    }//using
                }//if
            }//try
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        //计算并生成报告
        private void 计算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                tabControl.SelectedTab = tabControl.TabPages[0];
                InitialData();//初始化数据
                              //把表格数据导入并计算
                for (int i = 0; i < dataGV.RowCount; i++)
                {
                    _1behindD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[2].Value));
                    _2behindD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[3].Value));
                    _1frontD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[4].Value));
                    _2frontD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[5].Value));
                    dataGV.Rows[i].Cells[6].Value = (_1behindD[i] - _1frontD[i]).ToString("0.000");//距离差1
                    dataGV.Rows[i].Cells[7].Value = (_2behindD[i] - _2frontD[i]).ToString("0.000");//距离差2
                    _1deltaD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[6].Value));
                    _2deltaD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[7].Value));
                    dataGV.Rows[i].Cells[8].Value = ((_1deltaD[i] + _2deltaD[i]) / 2).ToString("0.000");//距离差d
                    _deltaD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[8].Value));

                    _1behindM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[10].Value));
                    _1frontM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[12].Value));
                    _2frontM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[13].Value));
                    _2behindM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[11].Value));
                    dataGV.Rows[i].Cells[14].Value = (_1behindM[i] - _2behindM[i]).ToString("0.000");//后视中丝差
                    dataGV.Rows[i].Cells[15].Value = (_1frontM[i] - _2frontM[i]).ToString("0.000");//前视中丝差
                    _behindDeltaM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[14].Value));
                    _frontDeltaM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[15].Value));

                    dataGV.Rows[i].Cells[16].Value = (_1behindM[i] - _1frontM[i]).ToString("0.000");//高差1
                    dataGV.Rows[i].Cells[17].Value = (_2behindM[i] - _2frontM[i]).ToString("0.000");//高差2
                    _1Height.Add(Convert.ToSingle(dataGV.Rows[i].Cells[16].Value));
                    _2Height.Add(Convert.ToSingle(dataGV.Rows[i].Cells[17].Value));
                    dataGV.Rows[i].Cells[18].Value = (_behindDeltaM[i] - _frontDeltaM[i]).ToString("0.000");//中丝差
                    _deltaM.Add(Convert.ToSingle(dataGV.Rows[i].Cells[18].Value));
                    dataGV.Rows[i].Cells[19].Value = ((_1Height[i] + _2Height[i]) / 2).ToString("0.000");//高差
                    _Height.Add(Convert.ToSingle(dataGV.Rows[i].Cells[19].Value));
                }

                dataGV.Rows[0].Cells[9].Value = _deltaD[0];
                _totalD.Add(Convert.ToSingle(dataGV.Rows[0].Cells[9].Value));//第一个Σd
                for (int i = 1; i < dataGV.RowCount; i++)//其余的Σd
                {
                    dataGV.Rows[i].Cells[9].Value = (_totalD[i - 1] + _deltaD[i]).ToString("0.000");//Σd
                    _totalD.Add(Convert.ToSingle(dataGV.Rows[i].Cells[9].Value));
                }

                //计算高程 距离
                float h1 = 0, s1 = 0;
                for (int i = 0; i < 4; i++)
                {
                    h1 += Convert.ToSingle(dataGV.Rows[i].Cells[dataGV.ColumnCount - 1].Value);
                    s1 += Convert.ToSingle((_1behindD[i] + _1frontD[i] + _2behindD[i] + _2frontD[i]) / 2);
                }
                H[0] = h1;
                S[0] = s1;

                float h2 = 0, s2 = 0;
                for (int i = 4; i < 10; i++)
                {
                    h2 += Convert.ToSingle(dataGV.Rows[i].Cells[dataGV.ColumnCount - 1].Value);
                    s2 += Convert.ToSingle((_1behindD[i] + _1frontD[i] + _2behindD[i] + _2frontD[i]) / 2);
                }
                H[1] = h2;
                S[1] = s2;

                float h3 = 0, s3 = 0;
                for (int i = 10; i < 14; i++)
                {
                    h3 += Convert.ToSingle(dataGV.Rows[i].Cells[dataGV.ColumnCount - 1].Value);
                    s3 += Convert.ToSingle((_1behindD[i] + _1frontD[i] + _2behindD[i] + _2frontD[i]) / 2);
                }
                H[2] = h3;
                S[2] = s3;

                float h4 = 0, s4 = 0;
                for (int i = 14; i < dataGV.RowCount; i++)
                {
                    h4 += Convert.ToSingle(dataGV.Rows[i].Cells[dataGV.ColumnCount - 1].Value);
                    s4 += Convert.ToSingle((_1behindD[i] + _1frontD[i] + _2behindD[i] + _2frontD[i]) / 2);
                }
                H[3] = h4;
                S[3] = s4;

                bhc = H.Sum() - (endH - beginH);//闭合高差
                for (int i = 0; i < 4; i++)
                {
                    V[i] = -bhc * S[i] / (S.Sum());//高差改正数计算
                }

                for (int i = 0; i < 4; i++)
                {
                    VH[i] = H[i] + V[i];//分配闭合差
                }

                //报告生成
                richTextBox1.Clear();
                richTextBox1.Text += "*************************附合水准路线平差*************************\n";
                richTextBox1.Text += "*****************************************************************\n";
                richTextBox1.Text += "\n--------------------------------------------------------------------------------\n";
                richTextBox1.Text += "测站数据\n";
                for (int i = 0; i < dataGV.RowCount; i++)
                {
                    for (int j = 0; j < dataGV.ColumnCount; j++)
                    {
                        richTextBox1.Text += string.Format("{0,10}", dataGV.Rows[i].Cells[j].Value);
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "\n--------------------------------------------------------------------------------\n";

                richTextBox1.Text += "改正前的各点之间的高差";
                for (int i = 0; i < 4; i++)
                {
                    richTextBox1.Text += string.Format("{0,-12}", H[i]);
                }
                richTextBox1.Text += "\n改正后的各点之间的高差";
                for (int i = 0; i < 4; i++)
                {
                    richTextBox1.Text += string.Format("{0,-12}", VH[i]);
                }

                richTextBox1.Text += "\n水准路线闭合高差\n";
                richTextBox1.Text += string.Format("{0,-8}", bhc.ToString("0.000"));
                richTextBox1.Text += "\n高差改正数\n";
                for (int i = 0; i < 4; i++)
                {
                    richTextBox1.Text += string.Format("{0,-8}", V[i].ToString("0.000"));
                }
                richTextBox1.Text += "\n--------------------------------------------------------------------------------\n";
                //-----------------暂时实现的三阶矩阵的一些计算----------------------//
                #region 
                richTextBox1.Text += "原矩阵\n";
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", ResourceMatrix[i, j]);
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "\n矩阵的值\n";
                richTextBox1.Text += string.Format("{0,-8}",
                    calculate.GetMatrixNumber(
                    ResourceMatrix[0, 0], ResourceMatrix[0, 1], ResourceMatrix[0, 2],
                    ResourceMatrix[1, 0], ResourceMatrix[1, 1], ResourceMatrix[1, 2],
                    ResourceMatrix[2, 0], ResourceMatrix[2, 1], ResourceMatrix[2, 2]));
                richTextBox1.Text += "\n";
                float[,] invMatrix = new float[3, 3];
                invMatrix = calculate.inverseThirdMatrix(
                     ResourceMatrix[0, 0], ResourceMatrix[0, 1], ResourceMatrix[0, 2],
                     ResourceMatrix[1, 0], ResourceMatrix[1, 1], ResourceMatrix[1, 2],
                     ResourceMatrix[2, 0], ResourceMatrix[2, 1], ResourceMatrix[2, 2]);
                richTextBox1.Text += "矩阵的逆\n";
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-12}", invMatrix[i, j]);
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "\n";
                #endregion
                //-----------------暂时实现的三阶矩阵的一些计算----------------------//
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", ResourceMatrix[i, j]);
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "\n";
                richTextBox1.Text += "矩阵求逆\n";

                richTextBox1.Text += "矩阵求和\n";

                richTextBox1.Text += "矩阵求转置\n";

                richTextBox1.Text += "L矩阵\n";

                richTextBox1.Text += "x矩阵\n";

                richTextBox1.Text += "invBTPB矩阵\n";

                richTextBox1.Text += "高程平差值计算\n";


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        //绘示意图
        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                tabControl.SelectedTab = tabControl.TabPages[1];
                int a = pictureBox1.Width;
                int b = pictureBox1.Height;
                image = new Bitmap(a, b);
                Graphics g = Graphics.FromImage(image);
                g.Clear(Color.White);

                //g.ScaleTransform(1, -1);
                //g.TranslateTransform(0, -b);

                SolidBrush brush = new SolidBrush(Color.Black);
                Pen line = new Pen(brush, 1);
                Pen p = new Pen(brush, 2);
                Pen words = new Pen(Color.Black, 2);
                Font font = new Font("黑体", 15);

                PointF[] point = new PointF[5];
                point[0] = new PointF(100f, 400f);
                point[1] = new PointF(300f, 250f);
                point[2] = new PointF(500f, 400f);
                point[3] = new PointF(700f, 200f);
                point[4] = new PointF(900f, 400f);

                //---------------↑可调↑---------------//

                int D = 15;
                for (int i = 0; i < point.Length; i++)
                {
                    g.DrawEllipse(p, point[i].X - D / 2, point[i].Y - D / 2, D, D);
                }
                g.DrawCurve(line, point);//画曲线DrawCurve

                //未知点的叉
                //public int deltaFunc(int  x,int y )
                //{
                //     float delta = Convert.ToSingle(D / 2 / Math.Sqrt(2));
                //     g.DrawLine(p, point[0].X - delta, point[0].Y - delta, point[0].X + delta, point[0].Y + delta);

                //return 0;
                //}

                float delta = Convert.ToSingle(D / 2 / Math.Sqrt(2));
                g.DrawLine(p, point[0].X - delta, point[0].Y - delta, point[0].X + delta, point[0].Y + delta);
                g.DrawLine(p, point[0].X - delta, point[0].Y + delta, point[0].X + delta, point[0].Y - delta);
                g.DrawLine(p, point[4].X - delta, point[4].Y - delta, point[4].X + delta, point[4].Y + delta);
                g.DrawLine(p, point[4].X - delta, point[4].Y + delta, point[4].X + delta, point[4].Y - delta);
                //每个点的注记
                g.DrawString("P51", font, brush, point[0]);
                g.DrawString("B68", font, brush, point[1]);
                g.DrawString("B01", font, brush, point[2]);
                g.DrawString("P29", font, brush, point[3]);
                g.DrawString("Q48", font, brush, point[4]);
                //标题文字
                g.DrawString("附合水准平差路线示意图", font, brush, _behindDeltaM[0], _behindDeltaM[0]);//鲁棒性
                //标出高差 和 距离
                g.DrawString(VH[0].ToString("0.000") + "m", font, brush, (point[0].X + point[1].X) / 2, (point[0].Y + point[1].Y) / 2 - 40);
                g.DrawString(S[0].ToString("0.000") + "m", font, brush, (point[0].X + point[1].X) / 2, (point[0].Y + point[1].Y) / 2 - 20);
                g.DrawString(VH[1].ToString("0.000") + "m", font, brush, (point[1].X + point[2].X) / 2, (point[1].Y + point[2].Y) / 2);
                g.DrawString(S[1].ToString("0.000") + "m", font, brush, (point[1].X + point[2].X) / 2, (point[1].Y + point[2].Y) / 2 + 20);
                g.DrawString(VH[2].ToString("0.000") + "m", font, brush, (point[2].X + point[3].X) / 2, (point[2].Y + point[3].Y) / 2);
                g.DrawString(S[2].ToString("0.000") + "m", font, brush, (point[2].X + point[3].X) / 2, (point[2].Y + point[3].Y) / 2 + 20);
                g.DrawString(VH[3].ToString("0.000") + "m", font, brush, (point[3].X + point[4].X) / 2, (point[3].Y + point[4].Y) / 2);
                g.DrawString(S[3].ToString("0.000") + "m", font, brush, (point[3].X + point[4].X) / 2, (point[3].Y + point[4].Y) / 2 + 20);

                //g.DrawPolygon()
                pictureBox1.Image = (Image)image;

                g.Dispose();//释放资源
                line.Dispose();
                p.Dispose();
                words.Dispose();
                font.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        //保存图形
        private void 保存图形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog SaveJpgFile = new SaveFileDialog();
                SaveJpgFile.Title = "保存报告为jpg文件";
                SaveJpgFile.Filter = "(jpg文件)|*.jpg";
                if (SaveJpgFile.ShowDialog() == DialogResult.OK)
                {
                    image.Save(SaveJpgFile.FileName);
                }
                MessageBox.Show("保存图片成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //保存报告
        private void 保存报告ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog SaveTxtFile = new SaveFileDialog();
                SaveTxtFile.Title = "保存报告为txt文件";
                SaveTxtFile.Filter = "(txt文件)|*.txt";
                if (SaveTxtFile.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(SaveTxtFile.FileName))
                    {
                        sw.Write(richTextBox1.Text);
                    }
                    if (richTextBox1.Text == "")
                    {
                        MessageBox.Show("报告为空！");
                    }
                    else
                    {
                        MessageBox.Show("保存报告成功！");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //查看报告
        private void 查看ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl.SelectedTab = tabControl.TabPages[2];
        }
        //清除所有
        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
        //放大
        private void 放大_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }
        }
        //缩小
        private void 缩小_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }
        //退出
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
