﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 道路曲线要素与里程桩计算
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region 时间控件
        private void Form1_Load(object sender, EventArgs e)
        {
            DGV_origin.AllowUserToAddRows = false;

            toolStripStatusLabel3.Text = DateTime.Now.ToString();
            timer1.Enabled = true;
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
        }
        #endregion
        #region 放大缩小
        private void Bigger_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }
        }

        private void Smaller_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }
        #endregion
        #region 刷新
        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
        #endregion

        #region 变量定义 (全局变量)及初始化
        double Xmax, Ymax, Xmin, Ymin;  //画图用
        List<Point1> point1;            //所有已知点 包括起点 终点 交点
        List<Point1> yuanzhu;           //圆柱
        List<Point1> huanzhu;           //缓柱
        List<Point1> Stake;             //定桩点
        List<double> fangwei;           //方位角
        double m, P, B;                 //缓和曲线参数
        double T, L, E, q1, Ls, Th, Lh, Eh, q2;//缓和曲线要素
        double zhuan1, zhuan2;          //线路转角
        int k1, k2;                     //线路转角
        double R1, R2;                  //圆曲线半径
        static Bitmap image;
        Calculate Cal = new Calculate();//计算类
        //数据初始化
        public void InitializeData()
        {
            point1 = new List<Point1>();
            yuanzhu = new List<Point1>();
            huanzhu = new List<Point1>();
            Stake = new List<Point1>();
            fangwei = new List<double>();
        }
        #endregion

        #region 其余表格的初始化
        public void InitializeOtherDGV()
        {
            DGV_mainPoint.Rows.Clear();
            DGV_Curve.Rows.Clear();
            DGV_Stake.Rows.Clear();
            //主点数据
            DGV_mainPoint.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_mainPoint.ColumnCount = 4;
            DGV_mainPoint.Columns[0].HeaderText = "点名";
            DGV_mainPoint.Columns[1].HeaderText = "X坐标";
            DGV_mainPoint.Columns[2].HeaderText = "Y坐标";
            DGV_mainPoint.Columns[3].HeaderText = "里程";
            //曲线要素
            DGV_Curve.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Curve.ColumnCount = 2;
            DGV_Curve.Columns[0].HeaderText = "曲线要素";
            DGV_Curve.Columns[1].HeaderText = "数值";
            //定桩数据
            DGV_Stake.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Stake.ColumnCount = 5;
            DGV_Stake.Columns[0].HeaderText = "点名";
            DGV_Stake.Columns[1].HeaderText = "里程";
            DGV_Stake.Columns[2].HeaderText = "X坐标";
            DGV_Stake.Columns[3].HeaderText = "Y坐标";
            DGV_Stake.Columns[4].HeaderText = "曲线类型";
        }
        #endregion
        #region 读取txt数据到表格
        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                #region 初始化
                DGV_origin.Rows.Clear();
                pictureBox1.Image = null;
                richTextBox1.Text = "";
                InitializeOtherDGV();
                #endregion
                #region 打开文件并导入数据到初表格
                open.Title = "打开txt文件";
                open.Filter = "txt文件|*.txt";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    List<string> _list = new List<string>();
                    string[] lines = File.ReadAllLines(open.FileName, Encoding.Default);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        _list.Add(lines[i]);
                    }
                    //表格操作
                    DGV_origin.RowCount = _list.Count;
                    DGV_origin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    DGV_origin.ColumnHeadersHeight = 28;
                    DGV_origin.ColumnCount = 5;
                    DGV_origin.Columns[0].HeaderText = "起点";
                    DGV_origin.Columns[1].HeaderText = "X坐标";
                    DGV_origin.Columns[2].HeaderText = "Y坐标";
                    DGV_origin.Columns[3].HeaderText = "圆曲线半径";
                    DGV_origin.Columns[4].HeaderText = "缓曲线长";
                    for (int i = 0; i < DGV_origin.RowCount; i++)
                    {
                        for (int j = 0; j < DGV_origin.ColumnCount; j++)
                        {
                            DGV_origin.Rows[i].Cells[j].Value = _list[i].Split(',')[j];
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 计算并生成报告
        private void 计算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            InitializeData();
            try
            {
                #region 从表格导入数据
                //------------导入所有已知点的点名、X、Y------------//
                for (int i = 0; i < DGV_origin.RowCount; i++)
                {
                    Point1 p = new Point1();
                    p._name = DGV_origin.Rows[i].Cells[0].Value.ToString();
                    p._X = Convert.ToDouble(DGV_origin.Rows[i].Cells[1].Value);
                    p._Y = Convert.ToDouble(DGV_origin.Rows[i].Cells[2].Value);
                    point1.Add(p);
                }
                #endregion
                //------------计算同时报告生成------------//
                richTextBox1.Text = "道路曲线要素与里程桩计算\n\n--------------\n";
                richTextBox1.Text += "一、圆曲线计算\n";
                //------------线路转角------------//
                richTextBox1.Text += "1.线路转角α\n";

                fangwei.Add(Cal.fangweijiao(point1[0]._X, point1[0]._Y, point1[1]._X, point1[1]._Y));
                fangwei.Add(Cal.fangweijiao(point1[1]._X, point1[1]._Y, point1[2]._X, point1[2]._Y));
                fangwei.Add(Cal.fangweijiao(point1[2]._X, point1[2]._Y, point1[3]._X, point1[3]._Y));

                R1 = Convert.ToDouble(DGV_origin.Rows[1].Cells[3].Value);
                R2 = Convert.ToDouble(DGV_origin.Rows[2].Cells[3].Value);
                Ls = Convert.ToDouble(DGV_origin.Rows[2].Cells[4].Value);
                //转角1
                zhuan1 = Cal.JulgeZhuan(fangwei[1] - fangwei[0]);
                if (zhuan1 > 0)
                { k1 = 1; }
                else
                { k1 = -1; }
                zhuan1 = Math.Abs(zhuan1);
                //此处判断左右角 大于0右角 小于0左角
                //转角2
                zhuan2 = Cal.JulgeZhuan(fangwei[2] - fangwei[1]);
                if (zhuan2 > 0)
                { k2 = 1; }
                else
                { k2 = -1; }
                zhuan2 = Math.Abs(zhuan2);

                richTextBox1.Text += "\t线路转角:  " + Cal.outputDDmmss(Cal.hudutodms(zhuan1)) + "\n";
                //------------圆曲线要素------------//
                richTextBox1.Text += "2.圆曲线要素\n";
                T = R1 * Math.Tan(zhuan1 / 2);
                L = R1 * zhuan1;
                E = R1 * (1 / Math.Cos(zhuan1 / 2) - 1);
                q1 = 2 * T - L;
                richTextBox1.Text += "\t切线长T:  " + Math.Round(T, 6) + "\n";
                richTextBox1.Text += "\t曲线长L:  " + Math.Round(L, 6) + "\n";
                richTextBox1.Text += "\t外矢距E:  " + Math.Round(E, 6) + "\n";
                richTextBox1.Text += "\t切曲差q:  " + Math.Round(q1, 6) + "\n";
                //------------圆曲线主点里程-------------主点ZY,YZ坐标------------//
                double KJD1 = Math.Sqrt(Math.Pow((point1[1]._X - point1[0]._X), 2) + Math.Pow((point1[1]._Y - point1[0]._Y), 2));//起点p里程0
                //算ZY
                Point1 f = new Point1();
                f._name = "ZY";
                f._X = point1[1]._X - T * Math.Cos(fangwei[0]);
                f._Y = point1[1]._Y - T * Math.Sin(fangwei[0]);
                f._licheng = KJD1 - T;
                yuanzhu.Add(f);
                //算QZ1
                double KQZ1 = KJD1 - T + L / 2;//QZ的里程
                double huchang1 = KQZ1 - (KJD1 - T);//ZY到QZ的弧长
                double jiao1 = huchang1 / R1;//弧长所对的圆心角s
                double x1 = R1 * Math.Sin(jiao1);//Xi'
                double y1 = R1 * (1 - Math.Cos(jiao1));//Yi'
                f = new Point1();
                f._name = "QZ";
                f._X = yuanzhu[0]._X + x1 * Math.Cos(fangwei[0]) - k1 * y1 * Math.Sin(fangwei[0]);
                f._Y = yuanzhu[0]._Y + x1 * Math.Sin(fangwei[0]) + k1 * y1 * Math.Cos(fangwei[0]);
                f._licheng = KQZ1;
                yuanzhu.Add(f);
                //算YZ
                f = new Point1();
                f._name = "YZ";
                f._X = point1[1]._X + T * Math.Cos(fangwei[1]);
                f._Y = point1[1]._Y + T * Math.Sin(fangwei[1]);
                f._licheng = KJD1 - T + L;
                if (2 * T - q1 != L)
                {
                    MessageBox.Show("数据错误");
                    return;
                }
                yuanzhu.Add(f);

                richTextBox1.Text += "3.圆曲线主点里程\n";
                richTextBox1.Text += "\tKZY:  " + Math.Round(yuanzhu[0]._licheng, 3) + "\n";
                richTextBox1.Text += "\tKQZ:  " + Math.Round(yuanzhu[1]._licheng, 3) + "\n";
                richTextBox1.Text += "\tKYZ:  " + Math.Round(yuanzhu[2]._licheng, 3) + "\n";
                richTextBox1.Text += "4.主点ZY,YZ坐标\n";
                richTextBox1.Text += "\tXZY:  " + Math.Round(yuanzhu[0]._X, 3) + "\n";
                richTextBox1.Text += "\tYZY:  " + Math.Round(yuanzhu[0]._Y, 3) + "\n";
                richTextBox1.Text += "\tXYZ:  " + Math.Round(yuanzhu[2]._X, 3) + "\n";
                richTextBox1.Text += "\tYYZ:  " + Math.Round(yuanzhu[2]._Y, 3) + "\n";
                richTextBox1.Text += "5.圆曲线中线点独立坐标(包括QZ点)\n";
                richTextBox1.Text += "\tXQZ:  " + Math.Round(yuanzhu[1]._X, 3) + "\n";
                richTextBox1.Text += "\tYQZ:  " + Math.Round(yuanzhu[1]._Y, 3) + "\n";


                richTextBox1.Text += "--------------\n二、带缓和曲线的圆曲线\n";
                //------------计算缓和曲线参数------------//
                richTextBox1.Text += "1.计算缓和曲线参数\n";
                m = Ls / 2 - Math.Pow(Ls, 3) / (240 * R2 * R2);
                P = Ls * Ls / (24 * R2);
                B = Ls / (2 * R2);
                richTextBox1.Text += "\tm:  " + Math.Round(m, 6) + "\n";
                richTextBox1.Text += "\tP:  " + Math.Round(P, 6) + "\n";
                richTextBox1.Text += "\tβ:  " + Math.Round(B, 6) + "\n";
                richTextBox1.Text += "\t线路转角α:  " + Cal.outputDDmmss(Cal.hudutodms(zhuan2)) + "\n";
                //------------曲线综合要素计算------------//
                richTextBox1.Text += "2.曲线综合要素计算\n";
                Th = m + (R2 + P) * Math.Tan(zhuan2 / 2);
                Lh = R2 * (zhuan2 - 2 * B) + 2 * Ls;
                Eh = (R2 + P) * (1 / Math.Cos(zhuan2 / 2)) - R2;
                q2 = 2 * Th - Lh;
                richTextBox1.Text += "\tTh:  " + Math.Round(Th, 6) + "\n";
                richTextBox1.Text += "\tLh:  " + Math.Round(Lh, 6) + "\n";
                richTextBox1.Text += "\tEh:  " + Math.Round(Eh, 6) + "\n";
                richTextBox1.Text += "\tq2:  " + Math.Round(q2, 6) + "\n";
                //------------曲线主点里程计算----------曲线线路主点ZH、HZ坐标计算------------//
                //算主点里程
                double KJD2 = KJD1 + Math.Sqrt(Math.Pow((point1[2]._X - point1[1]._X), 2) + Math.Pow((point1[2]._Y - point1[1]._Y), 2));
                double KZH = KJD2 - Th;
                double KHY = KZH + Ls;
                double KQZ2 = KZH + Lh / 2;
                double KYH = KZH + Lh - Ls;
                double KHZ = KYH + Ls;
                //算ZH
                f = new Point1();
                f._name = "ZH";
                f._X = point1[2]._X - Th * Math.Cos(fangwei[1]);
                f._Y = point1[2]._Y - Th * Math.Sin(fangwei[1]);
                f._licheng = KZH;
                huanzhu.Add(f);
                //算HY
                huanzhu.Add(Cal.huanquxian1(f, KHY, "HY", R2, Ls, fangwei[1], k2));
                //算QZ2
                huanzhu.Add(Cal.huanquxian2(f, KQZ2, "QZ", R2, B, m, P, Ls, fangwei[1], k2));
                //算YH
                double xhz = point1[2]._X + Th * Math.Cos(fangwei[2]);
                double yhz = point1[2]._Y + Th * Math.Sin(fangwei[2]);
                double Li = KHZ - KYH;
                double xyh = Li - Math.Pow(Li, 5) / (40 * R2 * R2 * Ls * Ls);
                double yyh = Li * Li * Li / (6 * R2 * Ls);
                f = new Point1();
                f._name = "YH";
                f._X = xhz + xyh * Math.Cos(Math.PI + fangwei[2]) + k2 * yyh * Math.Sin(fangwei[1]);
                f._Y = yhz + xyh * Math.Sin(Math.PI + fangwei[2]) - k2 * yyh * Math.Cos(Math.PI + fangwei[2]);
                f._licheng = KYH;
                huanzhu.Add(f);//添加YH
                //算HZ
                f = new Point1();
                f._name = "HZ";
                f._X = point1[2]._X + Th * Math.Cos(fangwei[2]);
                f._Y = point1[2]._Y + Th * Math.Sin(fangwei[2]);
                f._licheng = KHZ;
                huanzhu.Add(f);//添加HZ
                double KQ = KJD2 + Math.Sqrt(Math.Pow(point1[2]._X - point1[3]._X, 2) + Math.Pow(point1[2]._Y - point1[3]._Y, 2));

                richTextBox1.Text += "3.曲线主点里程计算\n";
                richTextBox1.Text += "\tKZH:  " + Math.Round(huanzhu[0]._licheng, 3) + "\n";
                richTextBox1.Text += "\tKHY:  " + Math.Round(huanzhu[1]._licheng, 3) + "\n";
                richTextBox1.Text += "\tKQZ:  " + Math.Round(huanzhu[2]._licheng, 3) + "\n";
                richTextBox1.Text += "\tKYH:  " + Math.Round(huanzhu[3]._licheng, 3) + "\n";
                richTextBox1.Text += "\tKHZ:  " + Math.Round(huanzhu[4]._licheng, 3) + "\n";
                richTextBox1.Text += "4.曲线线路主点ZH、HZ坐标计算\n";
                richTextBox1.Text += "\tXZH:  " + Math.Round(huanzhu[0]._X, 3) + "\n";
                richTextBox1.Text += "\tYZH:  " + Math.Round(huanzhu[0]._Y, 3) + "\n";
                richTextBox1.Text += "\tXHZ:  " + Math.Round(huanzhu[4]._X, 3) + "\n";
                richTextBox1.Text += "\tYHZ:  " + Math.Round(huanzhu[4]._Y, 3) + "\n";
                richTextBox1.Text += "5.圆曲线中线点独立坐标\n";
                richTextBox1.Text += "\tXHY:  " + Math.Round(huanzhu[1]._X, 3) + "\n";
                richTextBox1.Text += "\tYHY:  " + Math.Round(huanzhu[1]._Y, 3) + "\n";
                richTextBox1.Text += "\tXQZ:  " + Math.Round(huanzhu[2]._X, 3) + "\n";
                richTextBox1.Text += "\tYQZ:  " + Math.Round(huanzhu[2]._Y, 3) + "\n";
                richTextBox1.Text += "\tXYH:  " + Math.Round(huanzhu[3]._X, 3) + "\n";
                richTextBox1.Text += "\tYYH:  " + Math.Round(huanzhu[3]._Y, 3) + "\n";

                //---------------里程点计算---------------//

                int licheng = 0;
                for (int i = 0; licheng < KQ; i++)
                {
                    string dianhao = "Stake" + (i + 1);
                    Point1 p = new Point1();
                    p._name = dianhao;
                    p._licheng = licheng;
                    if (licheng < KJD1 - T)//未到达ZY
                    {
                        p._X = point1[0]._X + licheng * Math.Cos(fangwei[0]);
                        p._Y = point1[0]._Y + licheng * Math.Sin(fangwei[0]);
                        p.QXLX = "Line";
                    }
                    else if (licheng < KQZ1)//未到达QZ1
                    {
                        p = Cal.yuanquxian1(yuanzhu[0], licheng, dianhao, R1, fangwei[0], k1);
                        p.QXLX = "YQX";
                    }
                    else if (licheng < KJD1 + T)//未到达YZ
                    {
                        p = Cal.yuanquxian2(yuanzhu[1], licheng, dianhao, R1, fangwei[1], k1);
                        p.QXLX = "YQX";
                    }
                    else if (licheng < KZH)//未到达ZH
                    {
                        p._X = point1[1]._X + (licheng - KJD1) * Math.Cos(fangwei[1]);
                        p._Y = point1[1]._Y + (licheng - KJD1) * Math.Sin(fangwei[1]);
                        p.QXLX = "line";
                    }
                    else if (licheng < KHY)//未到达HY
                    {
                        p = Cal.huanquxian1(huanzhu[0], licheng, dianhao, R2, Ls, fangwei[1], k2);
                        p.QXLX = "HQX";
                    }
                    else if (licheng < KYH)//未到达YH
                    {
                        p = Cal.huanquxian2(huanzhu[0], licheng, dianhao, R2, B, m, P, Ls, fangwei[1], k2);
                        p.QXLX = "HQX";
                    }
                    else if (licheng < KHZ)//未到达HZ
                    {
                        p = Cal.huanquxian3(huanzhu[4], licheng, dianhao, R2, Ls, fangwei[2], k2);
                        p.QXLX = "HQX";
                    }
                    else//未到达Q
                    {
                        p._X = point1[2]._X + (licheng - KJD2) * Math.Cos(fangwei[2]);
                        p._Y = point1[2]._Y + (licheng - KJD2) * Math.Sin(fangwei[2]);
                        p.QXLX = "Line";
                    }
                    if (p._X > point1[3]._X)
                    { break; }
                    Stake.Add(p);
                    licheng += 5;
                }


                #region 将结果也输出到表格

                //---------------主点要素---------------//
                DGV_mainPoint.RowCount = yuanzhu.Count + huanzhu.Count;
                DGV_mainPoint.RowHeadersWidth = 100;
                DGV_mainPoint.Rows[0].HeaderCell.Value = "圆曲线";
                for (int i = 0; i < yuanzhu.Count; i++)
                {
                    DGV_mainPoint.Rows[i].Cells[0].Value = yuanzhu[i]._name;
                    DGV_mainPoint.Rows[i].Cells[1].Value = Math.Round(yuanzhu[i]._X, 3);
                    DGV_mainPoint.Rows[i].Cells[2].Value = Math.Round(yuanzhu[i]._Y, 3);
                    DGV_mainPoint.Rows[i].Cells[3].Value = Math.Round(yuanzhu[i]._licheng, 3);
                }
                DGV_mainPoint.Rows[yuanzhu.Count].HeaderCell.Value = "缓和曲线";
                for (int i = yuanzhu.Count; i < DGV_mainPoint.RowCount; i++)
                {
                    DGV_mainPoint.Rows[i].Cells[0].Value = huanzhu[i - yuanzhu.Count]._name;
                    DGV_mainPoint.Rows[i].Cells[1].Value = Math.Round(huanzhu[i - yuanzhu.Count]._X, 3);
                    DGV_mainPoint.Rows[i].Cells[2].Value = Math.Round(huanzhu[i - yuanzhu.Count]._Y, 3);
                    DGV_mainPoint.Rows[i].Cells[3].Value = Math.Round(huanzhu[i - yuanzhu.Count]._licheng, 3);
                }
                //---------------曲线要素---------------//
                DGV_Curve.RowCount = 10;
                DGV_Curve.RowHeadersWidth = 100;
                DGV_Curve.Rows[0].HeaderCell.Value = "圆曲线";
                DGV_Curve.Rows[0].Cells[0].Value = "线路转角α";
                DGV_Curve.Rows[0].Cells[1].Value = Cal.outputDDmmss(Cal.hudutodms(zhuan1));
                DGV_Curve.Rows[1].Cells[0].Value = "切线长T";
                DGV_Curve.Rows[1].Cells[1].Value = Math.Round(T, 3);
                DGV_Curve.Rows[2].Cells[0].Value = "曲线长L";
                DGV_Curve.Rows[2].Cells[1].Value = Math.Round(L, 3);
                DGV_Curve.Rows[3].Cells[0].Value = "外矢距E";
                DGV_Curve.Rows[3].Cells[1].Value = Math.Round(E, 3);
                DGV_Curve.Rows[4].Cells[0].Value = "切曲差q";
                DGV_Curve.Rows[4].Cells[1].Value = Math.Round(q1, 3);
                DGV_Curve.Rows[5].HeaderCell.Value = "缓和曲线";
                DGV_Curve.Rows[5].Cells[0].Value = "线路转角α";
                DGV_Curve.Rows[5].Cells[1].Value = Cal.outputDDmmss(Cal.hudutodms(zhuan2));
                DGV_Curve.Rows[6].Cells[0].Value = "切线长TH";
                DGV_Curve.Rows[6].Cells[1].Value = Math.Round(Th, 3);
                DGV_Curve.Rows[7].Cells[0].Value = "曲线长LH";
                DGV_Curve.Rows[7].Cells[1].Value = Math.Round(Lh, 3);
                DGV_Curve.Rows[8].Cells[0].Value = "外矢距EH";
                DGV_Curve.Rows[8].Cells[1].Value = Math.Round(Eh, 3);
                DGV_Curve.Rows[9].Cells[0].Value = "切曲差q";
                DGV_Curve.Rows[9].Cells[1].Value = Math.Round(q2, 3);
                //---------------定桩数据---------------//
                DGV_Stake.RowCount = Stake.Count;
                DGV_Stake.RowHeadersWidth = 100;
                for (int i = 0; i < DGV_Stake.RowCount; i++)
                {
                    DGV_Stake.Rows[i].Cells[0].Value = Stake[i]._name;
                    DGV_Stake.Rows[i].Cells[1].Value = Stake[i]._licheng;
                    DGV_Stake.Rows[i].Cells[2].Value = Math.Round(Stake[i]._X, 3);
                    DGV_Stake.Rows[i].Cells[3].Value = Math.Round(Stake[i]._Y, 3);
                    DGV_Stake.Rows[i].Cells[4].Value = Stake[i].QXLX; ;
                }

                #endregion

                //生成报告
                richTextBox1.Text += "已知点数据----------\n";
                richTextBox1.Text += "点名    \tX坐标    \tY坐标    \t\n";
                for (int i = 0; i < DGV_origin.RowCount; i++)
                {
                    for (int j = 0; j < DGV_origin.ColumnCount; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", DGV_origin.Rows[i].Cells[j].Value) + "\t";
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "主点数据----------\n";
                richTextBox1.Text += "点名    \tX坐标    \tY坐标    \t里程\n";
                for (int i = 0; i < DGV_mainPoint.RowCount; i++)
                {
                    for (int j = 0; j < DGV_mainPoint.ColumnCount; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", DGV_mainPoint.Rows[i].Cells[j].Value) + "\t";
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "曲线要素----------\n";
                for (int i = 0; i < DGV_Curve.RowCount; i++)
                {
                    for (int j = 0; j < DGV_Curve.ColumnCount; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", DGV_Curve.Rows[i].Cells[j].Value) + "\t";
                    }
                    richTextBox1.Text += "\n";
                }
                richTextBox1.Text += "定桩数据----------\n";
                richTextBox1.Text += "点名    \t里程    \tX坐标    \tY坐标    \t曲线类型\n";
                for (int i = 0; i < DGV_Stake.RowCount; i++)
                {
                    for (int j = 0; j < DGV_Stake.ColumnCount; j++)
                    {
                        richTextBox1.Text += string.Format("{0,-8}", DGV_Stake.Rows[i].Cells[j].Value) + "\t";
                    }
                    richTextBox1.Text += "\n";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion
        #region 绘制图形
        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[1];
            try
            {
                //------------找到最大最小------------//
                Xmax = 0; Ymin = 0;
                Xmin = 100000000000; Ymin = 100000000000;
                for (int i = 0; i < point1.Count; i++)
                {
                    if (Xmax < point1[i]._X) { Xmax = point1[i]._X; }
                    if (Ymax < point1[i]._Y) { Ymax = point1[i]._Y; }
                    if (Xmin > point1[i]._X) { Xmin = point1[i]._X; }
                    if (Ymin > point1[i]._Y) { Ymin = point1[i]._Y; }
                }
                Pen p = new Pen(Color.Black, 2.5f);
                Pen p1 = new Pen(Color.Red, 2);
                SolidBrush brush = new SolidBrush(Color.Gray);
                SolidBrush brush1 = new SolidBrush(Color.Blue);
                SolidBrush brush2 = new SolidBrush(Color.Yellow);
                SolidBrush brush3 = new SolidBrush(Color.Red);
                int width = (int)(Xmax - Xmin + 20) * 2 + 200;
                int height = (int)(Ymax - Ymin + 20) * 2 + 200;
                //int width = (int)(Ymax - Ymin + 20) * 2 + 200;
                //int height = (int)(Xmax - Xmin + 20) * 2 + 200;
                MessageBox.Show(width.ToString() + " " + height.ToString());
                image = new Bitmap(width, height);
                Graphics g = Graphics.FromImage(image);
                g.Clear(Color.White);

                //------------------画坐标轴------------------//
                PointF yuandian = new PointF(50, height - 50);
                PointF[] Xzhou = new PointF[3] { new PointF(50, 50), new PointF(75, 75), new PointF(25, 75) };
                PointF[] Yzhou = new PointF[3] { new PointF(width - 50, height - 50), new PointF(width - 75, height - 75), new PointF(width - 75, height - 25) };
                g.FillPolygon(Brushes.Black, Xzhou);//箭头
                g.FillPolygon(Brushes.Black, Yzhou);
                g.DrawLine(p, yuandian, Xzhou[0]);//轴线
                g.DrawLine(p, yuandian, Yzhou[0]);
                g.DrawString("X", new Font("宋体", 25), Brushes.Black, Xzhou[0]);
                g.DrawString("Y", new Font("宋体", 25), Brushes.Black, Yzhou[0]);

                Point[] StakeP = new Point[Stake.Count];//里程点
                for (int i = 0; i < Stake.Count; i++)
                {
                    StakeP[i].X = (int)(Stake[i]._X - Xmin + 10) * 2 + 100;
                    StakeP[i].Y = (int)(Stake[i]._Y - Ymin + 10) * 2 + 100;
                    g.DrawEllipse(p, StakeP[i].X - 5, StakeP[i].Y - 5, 10, 10);
                }

                Point[] yuanP = new Point[3];//圆曲线
                Point[] huanP = new Point[5];//缓和曲线
                Point[] LineP = new Point[point1.Count];//直线
                int D = 15;
                //直线
                for (int i = 0; i < point1.Count; i++)
                {
                    LineP[i].X = (int)(point1[i]._X - Xmin + 10) * 2 + 100;
                    LineP[i].Y = (int)(point1[i]._Y - Ymin + 10) * 2 + 100;
                }
                g.DrawLines(p, LineP);//先连线 再画点、注记、填充点 可以盖住线
                for (int i = 0; i < point1.Count; i++)
                {
                    g.DrawEllipse(p, LineP[i].X - D / 2, LineP[i].Y - D / 2, D, D);
                    g.FillEllipse(brush, LineP[i].X - D / 2, LineP[i].Y - D / 2, D, D);
                    g.DrawString(point1[i]._name, new Font("宋体", 15), brush, LineP[i].X, LineP[i].Y);
                }
                //圆曲线
                for (int i = 0; i < yuanP.Length; i++)
                {
                    yuanP[i].X = (int)(yuanzhu[i]._X - Xmin + 10) * 2 + 100;
                    yuanP[i].Y = (int)(yuanzhu[i]._Y - Ymin + 10) * 2 + 100;
                }
                g.DrawCurve(p1, yuanP);
                for (int i = 0; i < yuanP.Length; i++)
                {
                    g.DrawEllipse(p, yuanP[i].X - D / 2, yuanP[i].Y - D / 2, D, D);
                    g.FillEllipse(brush1, yuanP[i].X - D / 2, yuanP[i].Y - D / 2, D, D);
                    g.DrawString(yuanzhu[i]._name, new Font("宋体", 15), brush, yuanP[i].X, yuanP[i].Y - 40);
                }
                //缓和曲线
                for (int i = 0; i < huanP.Length; i++)
                {
                    huanP[i].X = (int)(huanzhu[i]._X - Xmin + 10) * 2 + 100;
                    huanP[i].Y = (int)(huanzhu[i]._Y - Ymin + 10) * 2 + 100;
                }
                g.DrawCurve(p1, huanP);
                for (int i = 0; i < huanP.Length; i++)
                {
                    g.DrawEllipse(p, huanP[i].X - D / 2, huanP[i].Y - D / 2, D, D);
                    g.FillEllipse(brush2, huanP[i].X - D / 2, huanP[i].Y - D / 2, D, D);
                    g.DrawString(huanzhu[i]._name, new Font("宋体", 15), brush, huanP[i].X - 10, huanP[i].Y + 10);
                }
                pictureBox1.Image = image;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 数据保存
        private void 数据保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存数据为txt";
                save.Filter = "txt文件|*.txt";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(save.FileName))
                    {
                        sw.Write(richTextBox1.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 绘图保存
        private void 绘图保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存图形为jpg";
                save.Filter = "jpg文件|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image.Save(save.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        #endregion
        #region 小功能
        private void 数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        private void 图形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[1];
        }

        private void 报告ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[2];
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("道路曲线要素与里程桩计算");
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion
    }
}
