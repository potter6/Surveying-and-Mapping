﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace 空间前方交会
{
    public class Method
    {
        #region 打开保存
        OpenFileDialog open = new OpenFileDialog();
        SaveFileDialog save = new SaveFileDialog();
        #endregion
        #region 定义已知数据变量
        List<double> Xs = new List<double>();
        List<double> Ys = new List<double>();
        List<double> Zs = new List<double>();
        List<double> o = new List<double>();
        List<double> p = new List<double>();
        List<double> q = new List<double>();
        List<double> f = new List<double>();
        List<double> x = new List<double>();
        List<double> y = new List<double>();
        #endregion
        #region 定义未知数据变量
        List<double> u = new List<double>();
        List<double> v = new List<double>();
        List<double> w = new List<double>();
        List<double> a = new List<double>();
        List<double> b = new List<double>();
        List<double> c = new List<double>();
        double Bu;
        double Bv;
        double Bw;
        List<double> N = new List<double>();
        double _X;
        double _Y;
        double _Z;
        #endregion

        /// <summary>
        /// 从txt中读取内外方位元素 并初始化表格
        /// </summary>
        /// <param name="dgv"></param>
        public void ReadFromTxt(DataGridView dgv)
        {
            open.Title = "内外方位元素数据文件读取";
            open.Filter = "(txt文件)|*.txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                List<string> _lines = new List<string>();
                string[] str = File.ReadAllLines(open.FileName, Encoding.Default);
                using (var sr = new StreamReader(open.FileName))
                {
                    for (int i = 0; i < str.Length; i++)
                    {
                        _lines.Add(str[i]);
                    }
                }
                //表格初始化
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;//行堆满
                dgv.AllowUserToAddRows = false;//不允许加行
                dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;//选中整行都变蓝
                dgv.ColumnCount = 4;
                dgv.RowCount = _lines.Count / 2;
                dgv.Columns[1].Name = "数据项";
                dgv.Columns[2].Name = "1504";
                dgv.Columns[3].Name = "1505";
                dgv.Rows[1].Cells[0].Value = "内方位元素";
                dgv.Rows[5].Cells[0].Value = "外方位元素";
                dgv.Rows[0].Cells[1].Value = "像点坐标x";
                dgv.Rows[1].Cells[1].Value = "像点坐标y";
                dgv.Rows[2].Cells[1].Value = "像片主距f";
                dgv.Rows[3].Cells[1].Value = "模型基线分量Xs";
                dgv.Rows[4].Cells[1].Value = "模型基线分量Ys";
                dgv.Rows[5].Cells[1].Value = "模型基线分量Zs";
                dgv.Rows[6].Cells[1].Value = "偏角";
                dgv.Rows[7].Cells[1].Value = "倾角";
                dgv.Rows[8].Cells[1].Value = "旋角";

                //向表格读入数据               
                for (int i = 0; i < dgv.RowCount - 3; i++)
                {
                    dgv.Rows[i + 3].Cells[2].Value = _lines[i];
                    dgv.Rows[i + 3].Cells[3].Value = _lines[i + 9];
                }
                for (int i = 0; i < dgv.RowCount - 6; i++)
                {
                    dgv.Rows[i].Cells[2].Value = _lines[i + 6];
                    dgv.Rows[i].Cells[3].Value = _lines[i + 6 + dgv.RowCount];
                }

                //将数据读入到变量中存储
                for (int i = 0; i < 2; i++)
                {
                    x.Add(Convert.ToDouble(dgv.Rows[0].Cells[i + 2].Value));
                    y.Add(Convert.ToDouble(dgv.Rows[1].Cells[i + 2].Value));
                    f.Add(Convert.ToDouble(dgv.Rows[2].Cells[i + 2].Value));
                    Xs.Add(Convert.ToDouble(dgv.Rows[3].Cells[i + 2].Value));
                    Ys.Add(Convert.ToDouble(dgv.Rows[4].Cells[i + 2].Value));
                    Zs.Add(Convert.ToDouble(dgv.Rows[5].Cells[i + 2].Value));
                    o.Add(Convert.ToDouble(dgv.Rows[6].Cells[i + 2].Value));
                    p.Add(Convert.ToDouble(dgv.Rows[7].Cells[i + 2].Value));
                    q.Add(Convert.ToDouble(dgv.Rows[8].Cells[i + 2].Value));
                }
                //表格行数和q的叠加
                dgv.RowCount = 25;
            }
        }
        /// <summary>
        /// 计算空间辅助坐标
        /// </summary>
        /// <param name="dgv"></param>
        public void CalculateFuZhu(DataGridView dgv)
        {
            dgv.Rows[10].Cells[0].Value = "像空间辅助坐标u1";
            dgv.Rows[11].Cells[0].Value = "像空间辅助坐标u2";
            dgv.Rows[12].Cells[0].Value = "像空间辅助坐标v1";
            dgv.Rows[13].Cells[0].Value = "像空间辅助坐标v2";
            dgv.Rows[14].Cells[0].Value = "像空间辅助坐标w1";
            dgv.Rows[15].Cells[0].Value = "像空间辅助坐标w2";

            double temp = Math.PI / 180;
            //计算ai，bi，ci旋转矩阵元素
            for (int i = 0; i < 2; i++)
            {
                //α-偏角 a
                //γ-倾角 b
                //β-旋角 c
                a.Add(Math.Cos(o[i] * temp) * Math.Cos(q[i] * temp) - Math.Sin(o[i] * temp) * Math.Sin(p[i] * temp) * Math.Sin(q[i] * temp));
                a.Add(-Math.Cos(o[i] * temp) * Math.Sin(q[i] * temp) - Math.Sin(o[i] * temp) * Math.Sin(p[i] * temp) * Math.Sin(q[i] * temp));
                a.Add(-Math.Sin(o[i] * temp) * Math.Cos(p[i] * temp));
                b.Add(Math.Cos(p[i] * temp) * Math.Sin(q[i] * temp));
                b.Add(Math.Cos(p[i] * temp) * Math.Cos(q[i] * temp));
                b.Add(-Math.Sin(p[i] * temp));
                c.Add(Math.Sin(o[i] * temp) * Math.Cos(q[i] * temp) + Math.Cos(o[i] * temp) * Math.Sin(p[i] * temp) * Math.Sin(q[i] * temp));
                c.Add(-Math.Sin(p[i] * temp) * Math.Sin(q[i] * temp) + Math.Cos(o[i] * temp) * Math.Sin(p[i] * temp) * Math.Cos(q[i] * temp));//最后的Sin->Cos
                c.Add(Math.Cos(o[i] * temp) * Math.Cos(p[i] * temp));
            }
            //计算像空间辅助坐标
            u.Add(a[0] * x[0] + a[1] * y[0] + a[2] * f[0]);
            v.Add(b[0] * x[0] + b[1] * y[0] + b[2] * f[0]);
            w.Add(c[0] * x[0] + c[1] * y[0] + c[2] * f[0]);
            //c[1]出现偏差 对应的是c12
            u.Add(a[3] * x[1] + a[4] * y[1] + a[5] * f[1]);
            v.Add(b[3] * x[1] + b[4] * y[1] + b[5] * f[1]);
            w.Add(c[3] * x[1] + c[4] * y[1] + c[5] * f[1]);
            //c[4]出现偏差 对应的是c22
            //list一个输出的数组 存储空间辅助坐标
            List<double> output = new List<double>();
            output.Add(u[0]);
            output.Add(u[1]);
            output.Add(v[0]);
            output.Add(v[1]);
            output.Add(w[0]);
            output.Add(w[1]);
            //输出结果
            for (int i = 0; i < 6; i++)
            {
                dgv.Rows[10 + i].Cells[1].Value = output[i];
                dgv.Rows[10 + i].Cells[1].Style.Font = new Font(dgv.DefaultCellStyle.Font, FontStyle.Bold);
            }

        }
        /// <summary>
        /// 获取投影系数
        /// </summary>
        /// <param name="dgv"></param>
        public void GetXiShu(DataGridView dgv)
        {
            dgv.Rows[18].Cells[0].Value = "投影系数N1";
            dgv.Rows[19].Cells[0].Value = "投影系数N2";
            //计算投影系数并存进变量中
            Bu = Xs[1] - Xs[0];
            Bv = Ys[1] - Ys[0];
            Bw = Zs[1] - Zs[0];
            N.Add((Bu * w[1] - Bw * u[1]) / (u[0] * w[1] - u[1] * w[0]));
            N.Add((Bu * w[0] - Bw * u[0]) / (u[0] * w[1] - u[1] * w[0]));
            //输出投影系数
            dgv.Rows[18].Cells[1].Value = N[0];
            dgv.Rows[19].Cells[1].Value = N[1];
            dgv.Rows[18].Cells[1].Style.Font = new Font(dgv.DefaultCellStyle.Font, FontStyle.Bold);
            dgv.Rows[19].Cells[1].Style.Font = new Font(dgv.DefaultCellStyle.Font, FontStyle.Bold);
        }
        /// <summary>
        /// 计算地面坐标
        /// </summary>
        /// <param name="dgv"></param>
        public void GetDiMian(DataGridView dgv)
        {
            dgv.Rows[21].Cells[0].Value = "地面摄影测量坐标X";
            dgv.Rows[22].Cells[0].Value = "地面摄影测量坐标Y";
            dgv.Rows[23].Cells[0].Value = "地面摄影测量坐标Z";

            _X = Xs[0] + N[0] * u[0];
            _Y = 0.5 * ((Ys[0] + N[0] * v[0]) + (Ys[1] + N[1] * v[1]));
            _Z = Zs[0] + N[0] * w[0];

            dgv.Rows[21].Cells[1].Value = _X;
            dgv.Rows[22].Cells[1].Value = _Y;
            dgv.Rows[23].Cells[1].Value = _Z;
            dgv.Rows[21].Cells[1].Style.Font = new Font(dgv.DefaultCellStyle.Font, FontStyle.Bold);
            dgv.Rows[22].Cells[1].Style.Font = new Font(dgv.DefaultCellStyle.Font, FontStyle.Bold);
            dgv.Rows[23].Cells[1].Style.Font = new Font(dgv.DefaultCellStyle.Font, FontStyle.Bold);

            dgv.AllowUserToAddRows = false;
        }
        /// <summary>
        /// 生成报告
        /// </summary>
        /// <param name="richtextbox"></param>
        public void GenerateReport(RichTextBox richtextbox)
        {
            richtextbox.Text = "*******************************\n**********空间前方交会**********\n*******************************\n\n";
            richtextbox.Text += "------------------------------------------------\n";
            string str1 = "像空间辅助坐标";
            richtextbox.Text += str1 + "u1: " + string.Format("{0,20}", u[0]) + "\n";
            richtextbox.Text += str1 + "u2: " + string.Format("{0,20}", u[1]) + "\n";
            richtextbox.Text += str1 + "v1: " + string.Format("{0,20}", v[0]) + "\n";
            richtextbox.Text += str1 + "v2: " + string.Format("{0,20}", v[1]) + "\n";
            richtextbox.Text += str1 + "w1: " + string.Format("{0,20}", w[0]) + "\n";
            richtextbox.Text += str1 + "w2: " + string.Format("{0,20}", w[1]) + "\n";
            string str2 = "投影系数";
            richtextbox.Text += str2 + "N1: " + string.Format("{0,27}", N[0]) + "\n";
            richtextbox.Text += str2 + "N2: " + string.Format("{0,27}", N[1]) + "\n";
            string str3 = "地面摄影测量坐标";
            richtextbox.Text += str3 + "X: " + string.Format("{0,18}", _X) + "\n";
            richtextbox.Text += str3 + "Y: " + string.Format("{0,18}", _Y) + "\n";
            richtextbox.Text += str3 + "Z: " + string.Format("{0,18}", _Z) + "\n";


        }
        /// <summary>
        /// 保存报告为txt
        /// </summary>
        /// <param name="richtextbox"></param>
        public void SaveAsTxt(RichTextBox richtextbox)
        {
            save.Title = "保存报告为txt";
            save.Filter = "(txt文件)|*txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                using (var sw = new StreamWriter(save.FileName))
                {
                    sw.Write(richtextbox.Text);
                }
            }
            MessageBox.Show("保存报告成功!");
        }
        public void SaveAsJpg(Bitmap image)
        {
            save.Title = "保存图形为jpg";
            save.Filter = "(jpg文件)|*.jpg";
            if (save.ShowDialog() == DialogResult.OK)
            {
                image.Save(save.FileName);
            }
        }
    }
}
