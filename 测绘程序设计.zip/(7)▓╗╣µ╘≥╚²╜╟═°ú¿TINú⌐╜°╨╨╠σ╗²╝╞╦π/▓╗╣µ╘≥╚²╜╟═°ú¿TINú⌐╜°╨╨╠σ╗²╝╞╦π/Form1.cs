﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 不规则三角网_TIN_进行体积计算
{
    public partial class Form1 : Form
    {
        //public static List<NPoint> point = new List<NPoint>();//点
        //public static List<sjx> t = new List<sjx>();//三角形
        public Form1()
        {
            InitializeComponent();
        }
        Calculate calculate = new Calculate();
        #region 打开和保存
        OpenFileDialog open = new OpenFileDialog();
        SaveFileDialog save = new SaveFileDialog();
        #endregion
        #region 定义变量
        double gaocheng;//存储基准高程
        double xmin, xmax, ymin, ymax;//存储初始矩形信息
        List<Point1> point1;//存储散点信息
        List<Line> S;//存储边信息
        List<sjx> T1;//存储三角形信息
        List<double> V;//存储斜三棱柱体积信息

        //List<double> Vcut;//存储挖方体积
        //List<double> Vfill;//存储填方体积

        #endregion

        Bitmap image;
        //初始化
        public void Chushihua()
        {
            point1 = new List<Point1>();
            S = new List<Line>();
            T1 = new List<sjx>();
            V = new List<double>();
        }

        #region 打开txt文件读取数据到表格中
        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DGV.Rows.Clear();
            pictureBox1.Image = null;
            richTextBox1.Text = "";
            try
            {
                open.Title = "打开点txt文件";
                open.Filter = "(txt文件)|*.txt";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    List<string> _list = new List<string>();
                    string[] lines = File.ReadAllLines(open.FileName, Encoding.Default);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        _list.Add(lines[i]);
                    }
                    #region 表格
                    DGV.RowCount = _list.Count;
                    DGV.ColumnCount = 4;
                    DGV.Columns[0].Name = "点";
                    DGV.Columns[1].Name = "X";
                    DGV.Columns[2].Name = "Y";
                    DGV.Columns[3].Name = "Z";
                    DGV.Columns[0].Width = 50;
                    DGV.Columns[1].Width = 80;
                    DGV.Columns[2].Width = 80;
                    DGV.Columns[3].Width = 80;
                    //DGV.RowHeadersVisible = false;
                    #endregion
                    int index = 0;
                    foreach (var i in _list)
                    {
                        DGV.Rows[index].Cells[0].Value = i.Split(',')[0];
                        DGV.Rows[index].Cells[1].Value = i.Split(',')[1];
                        DGV.Rows[index].Cells[2].Value = i.Split(',')[2];
                        DGV.Rows[index].Cells[3].Value = i.Split(',')[3];
                        index++;
                    }
                }//if
            }//try
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        #endregion
        #region 三角剖分
        private void 三角剖分ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Chushihua();

            #region 数据导入
            try
            {
                gaocheng = Convert.ToDouble(DH.Text);
            }
            catch
            {
                MessageBox.Show("请输入正确的初始高程!");
                return;
            }
            try
            {
                for (int i = 0; i < DGV.RowCount; i++)
                {
                    Point1 p = new Point1();
                    p.PointName = DGV.Rows[i].Cells[0].Value.ToString();
                    p.X = Convert.ToDouble(DGV.Rows[i].Cells[1].Value);
                    p.Y = Convert.ToDouble(DGV.Rows[i].Cells[2].Value);
                    p.Z = Convert.ToDouble(DGV.Rows[i].Cells[3].Value);
                    point1.Add(p);
                }
            }
            #endregion
            catch
            {
                MessageBox.Show("请输入正确的散点信息!");
                return;
            }

            xmin = 10000000000; ymin = 10000000000;
            ymax = 0; xmax = 0;
            for (int i = 0; i < point1.Count; i++)
            {
                if (xmin > point1[i].X) { xmin = point1[i].X; }
                if (ymin > point1[i].Y) { ymin = point1[i].Y; }
                if (xmax < point1[i].X) { xmax = point1[i].X; }
                if (ymax < point1[i].Y) { ymax = point1[i].Y; }
            }

            //生成初始矩形
            //生成初始三角网
            Point1 p1 = new Point1();
            Point1 p2 = new Point1();
            Point1 p3 = new Point1();
            Point1 p4 = new Point1();
            p1.X = xmin - 1; p1.Y = ymin - 1;
            p2.X = xmin - 1; p2.Y = ymax + 1;
            p3.X = xmax + 1; p3.Y = ymax - 1;
            p4.X = xmax + 1; p4.Y = ymin - 1;
            sjx sjx1 = new sjx();
            sjx1.p1 = p1; sjx1.p2 = p2; sjx1.p3 = p3;
            T1.Add(sjx1);
            sjx sjx2 = new sjx();
            sjx2.p1 = p1; sjx2.p2 = p3; sjx2.p3 = p4;
            T1.Add(sjx2);
            //通过遍历离散点，生成平面三角网
            double x0, y0, r;
            for (int i = 0; i < point1.Count; i++)
            {
                List<int> a = new List<int>();
                S.Clear();
                for (int j = 0; j < T1.Count; j++)
                {
                    x0 = calculate.X0(T1[j].p1.X, T1[j].p1.Y, T1[j].p2.X, T1[j].p2.Y, T1[j].p3.X, T1[j].p3.Y);
                    y0 = calculate.Y0(T1[j].p1.X, T1[j].p1.Y, T1[j].p2.X, T1[j].p2.Y, T1[j].p3.X, T1[j].p3.Y);
                    r = calculate.R(T1[j].p1.X, T1[j].p1.Y, x0, y0);
                    if (Math.Pow(point1[i].X - x0, 2) + Math.Pow(point1[i].Y - y0, 2) < r * r)
                    {
                        Line line1 = new Line();
                        Line line2 = new Line();
                        Line line3 = new Line();
                        line1.Begin = T1[j].p1; line1.End = T1[j].p2;
                        line2.Begin = T1[j].p2; line2.End = T1[j].p3;
                        line3.Begin = T1[j].p3; line3.End = T1[j].p1;
                        S.Add(line1); S.Add(line2); S.Add(line3);
                        a.Add(j);
                    }
                }

                for (int j = a.Count - 1; j >= 0; j--)
                {
                    T1.Remove(T1[a[j]]);
                }

                //寻找公共边并删除这些公共边
                for (int j = 0; j < S.Count; j++)
                {
                    for (int k = 0; k < S.Count; k++)
                    {
                        if (j != k)
                        {
                            if (S[j].Begin == S[k].Begin && S[j].End == S[k].End
                             || S[j].Begin == S[k].End && S[j].End == S[k].Begin)
                            {
                                S.Remove(S[k]);
                                S.Remove(S[j]);
                                if (j == 0)//为了减少循环次数 必须保留这个，否则画出来部分有误
                                { j = 0; }
                                else
                                { j--; }
                            }
                        }
                    }
                }

                for (int j = 0; j < S.Count; j++)
                {
                    sjx sjx3 = new sjx();
                    sjx3.p1 = point1[i]; sjx3.p2 = S[j].Begin; sjx3.p3 = S[j].End;
                    T1.Add(sjx3);
                }

            }//for(int i=0;i<point1.Count;i++)

            //构成不规则三角网
            List<int> b = new List<int>();
            for (int i = 0; i < T1.Count; i++)
            {
                if (T1[i].p1 == p1 || T1[i].p1 == p2 || T1[i].p1 == p3 || T1[i].p1 == p4
                 || T1[i].p2 == p1 || T1[i].p2 == p2 || T1[i].p2 == p3 || T1[i].p2 == p4
                 || T1[i].p3 == p1 || T1[i].p3 == p2 || T1[i].p3 == p3 || T1[i].p3 == p4)
                {
                    b.Add(i);
                }
            }

            for (int i = b.Count - 1; i >= 0; i--)
            {
                T1.Remove(T1[b[i]]);
            }

        }
        #endregion

        #region 计算填挖方量
        private void 计算填挖方量ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                #region 体积计算
                for (int i = 0; i < T1.Count; i++)
                {
                    double ss, hh;
                    ss = calculate.SS(T1[i]);
                    hh = calculate.H(T1[i], gaocheng);
                    V.Add(ss * hh);
                }
                #endregion

                #region 体积排序
                for (int i = 0; i < V.Count; i++)//冒泡排序，从小到大排序
                {
                    for (int j = 0; j < V.Count - 1 - i; j++)
                    {
                        if (V[j] > V[j + 1])
                        {
                            double temp = V[j + 1];
                            V[j + 1] = V[j];
                            V[j] = temp;
                        }
                    }
                }
                #endregion
                #region 三角形的填挖方计算（未完工）
                //#region 三角形的填挖方计算
                //Vcut = new List<double>();
                //Vfill = new List<double>();

                //int woqu = 0;
                //for (int i = 0; i < T1.Count; i++)
                //{
                //    //全挖方
                //    if (T1[i].p1.Z > gaocheng && T1[i].p2.Z > gaocheng && T1[i].p3.Z > gaocheng)
                //    { Vcut.Add(calculate.SS(T1[i]) * calculate.H(T1[i], gaocheng)); }
                //    //全填方
                //    else if (T1[i].p1.Z < gaocheng && T1[i].p2.Z < gaocheng && T1[i].p3.Z < gaocheng)
                //    { Vfill.Add(calculate.SS(T1[i]) * calculate.H(T1[i], gaocheng)); }
                //    //填和挖
                //    else
                //    {
                //        //有填也有挖
                //        woqu++;
                //        for (int j = 0; j < 3; j++)
                //        {
                //            //BordPoint.Add (T1[i].p1.X + Math.Abs((gaocheng - T1[i].p1.Z) / (T1[i].p2.Z - T1[i].p1.Z)) * (T1[i].p2.X - T1[i].p1.X));
                //            //BordPoint[i][j].Y = T1[i].p1.Y + Math.Abs((gaocheng - T1[i].p1.Z) / (T1[i].p2.Z - T1[i].p1.Z)) * (T1[i].p2.Y - T1[i].p1.Y));                       
                //            if (T1[i].p1.Z > gaocheng && T1[i].p2.Z < gaocheng && T1[i].p3.Z < gaocheng
                //             || T1[i].p1.Z < gaocheng && T1[i].p2.Z > gaocheng && T1[i].p3.Z < gaocheng
                //             || T1[i].p1.Z < gaocheng && T1[i].p2.Z < gaocheng && T1[i].p3.Z > gaocheng)
                //            {
                //                double h1, h2, h3; h1 = T1[i].p1.Z; h2 = T1[i].p2.Z; h3 = T1[i].p3.Z;
                //                //if (h1 > gaocheng)//如果是p1点高于参考高程
                //                //{
                //                //    double XI1 = T1[i].p1.X + Math.Abs((gaocheng - h1) / (h2 - h1)) * (T1[i].p2.X - T1[i].p1.X);
                //                //    double YI1 = T1[i].p1.Y + Math.Abs((gaocheng - h1) / (h2 - h1)) * (T1[i].p2.Y - T1[i].p1.Y);

                //                //}
                //                //if (h2 > gaocheng)//如果是p2点高于参考高程
                //                //{
                //                //    double XI2 = T1[i].p2.X + Math.Abs((gaocheng - h2) / (h3 - h1)) * (T1[i].p3.X - T1[i].p1.X);
                //                //    double YI2 = T1[i].p2.Y + Math.Abs((gaocheng - h2) / (h3 - h1)) * (T1[i].p3.Y - T1[i].p1.Y);
                //                //}
                //                //if (h3 > gaocheng)//如果是p3点高于参考高程
                //                //{
                //                //    double XI3 = T1[i].p3.X + Math.Abs((gaocheng - h3) / ());
                //                //    double YI3 = T1[i].p3.Y + Math.Abs((gaocheng - h3) / ());
                //                //}
                //            }
                //        }
                //    }
                //}
                //#endregion
                #endregion
                MessageBox.Show("基准高程为：    " + gaocheng + "m\n");
                MessageBox.Show("总体积为：   " + Math.Round(V.Sum(), 3) + "m³");
                MessageBox.Show("三角形个数：   " + T1.Count + "\n");
                #region 计算报告
                richTextBox1.Text = "不规则三角网体积计算\n";
                richTextBox1.Text += "---------------三角网基本信息---------------\n";
                richTextBox1.Text += "基准高程：  " + gaocheng + "m\n";
                richTextBox1.Text += "三角形个数：  " + T1.Count + "\n";
                //richTextBox1.Text += "填和挖三角形个数:   " + woqu + "\n";//
                richTextBox1.Text += "体积：  " + Math.Round(V.Sum(), 3) + "m³\n\n";
                //richTextBox1.Text += "挖方体积：  " + Math.Round(Vcut.Sum(), 3) + "m³\n";
                //richTextBox1.Text += "填方体积：  " + Math.Round(Vfill.Sum(), 3) + "m³\n\n";
                richTextBox1.Text += "---------------20个三角形说明---------------\n";
                richTextBox1.Text += "序号\t三个顶点\n";
                for (int i = 0; i < 20; i++)
                {
                    richTextBox1.Text += (i + 1) + "\t";
                    richTextBox1.Text += T1[i].p1.PointName + T1[i].p2.PointName + T1[i].p3.PointName + "\n";
                }
                richTextBox1.Text += "\n---------------体积最小的5个三棱柱体积---------------\n";
                for (int i = 0; i < 5; i++)
                {
                    richTextBox1.Text += (i + 1) + "\t";
                    richTextBox1.Text += Math.Round(V[i], 3) + "\n";
                }
                richTextBox1.Text += "\n---------------体积最大的5个三棱柱体积---------------\n";
                for (int i = 0; i < 5; i++)
                {
                    richTextBox1.Text += (i + 1) + "\t";
                    richTextBox1.Text += Math.Round(V[V.Count - 1 - i], 3) + "\n";
                }
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        #endregion
        #region 一键计算并生成TIN
        private void 一键计算_Click(object sender, EventArgs e)
        {
            三角剖分ToolStripMenuItem_Click(sender, e);
            绘图ToolStripMenuItem_Click(sender, e);
            计算填挖方量ToolStripMenuItem_Click(sender, e);
        }
        #endregion
        #region 绘制
        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                #region 绘制
                tabControl1.SelectedTab = tabControl1.TabPages[0];
                int _width = (int)(ymax - ymin + 20) * 20;
                int _height = (int)(xmax - xmin + 20) * 20;
                MessageBox.Show(ymax.ToString() + " " + ymin.ToString() + "\n" + xmax.ToString() + " " + xmin.ToString());
                //image = new Bitmap((int)(ymax - ymin + 20) * 20, (int)(xmax - xmin + 20) * 20);//放大整个绘图区域20倍，为了弥补位图分辨率低的缺点
                image = new Bitmap(_width, _height);
                MessageBox.Show(_width.ToString() + "\n" + _height.ToString());
                Graphics g = Graphics.FromImage(image);
                g.Clear(Color.White);
                Pen pen = new Pen(Color.Black, 2f);
                SolidBrush brush = new SolidBrush(Color.Red);//定义填充
                for (int i = 0; i < T1.Count; i++)//对所有三角形进行绘制
                {
                    #region 绘制三角形
                    //PointF[] pp = new PointF[3];
                    //pp[0].X = (float)(T1[i].p1.Y - (int)ymin + 5) * 20;
                    //pp[0].Y = -(float)(T1[i].p1.X - (int)xmax - 5) * 20;
                    //pp[1].X = (float)(T1[i].p2.Y - (int)ymin + 5) * 20;
                    //pp[1].Y = -(float)(T1[i].p2.X - (int)xmax - 5) * 20;
                    //pp[2].X = (float)(T1[i].p3.Y - (int)ymin + 5) * 20;
                    //pp[2].Y = -(float)(T1[i].p3.X - (int)xmax - 5) * 20;
                    //pp[0].X = (float)(T1[i].p1.Y - (int)ymin + 5) * 20;
                    //pp[0].Y = -(float)(T1[i].p1.X - (int)xmax - 5) * 20;
                    //g.DrawLines(pen, pp);
                    #endregion
                    #region 绘制直线
                    PointF begin = new PointF();
                    PointF end = new PointF();
                    //任意点的X和Y减去最小值归化到原点，再乘以20倍以适应位图大小
                    for (int j = 0; j < 3; j++)
                    {
                        if (j == 0)//p1-p2
                        {
                            begin.X = (float)(T1[i].p1.Y - (int)ymin + 10) * 20; //X和Y调换，(数学坐标系转换到测量坐标系)
                            begin.Y = -(float)(T1[i].p1.X - (int)xmax - 10) * 20;//X减去max再变成正数(像素坐标系转换数学坐标系)
                            end.X = (float)(T1[i].p2.Y - (int)ymin + 10) * 20;
                            end.Y = -(float)(T1[i].p2.X - (int)xmax - 10) * 20;
                        }
                        if (j == 1)//p2-p3
                        {
                            begin.X = (float)(T1[i].p2.Y - (int)ymin + 10) * 20;
                            begin.Y = -(float)(T1[i].p2.X - (int)xmax - 10) * 20;
                            end.X = (float)(T1[i].p3.Y - (int)ymin + 10) * 20;
                            end.Y = -(float)(T1[i].p3.X - (int)xmax - 10) * 20;
                        }
                        if (j == 2)//p3-p1
                        {
                            begin.X = (float)(T1[i].p3.Y - (int)ymin + 10) * 20;
                            begin.Y = -(float)(T1[i].p3.X - (int)xmax - 10) * 20;
                            end.X = (float)(T1[i].p1.Y - (int)ymin + 10) * 20;
                            end.Y = -(float)(T1[i].p1.X - (int)xmax - 10) * 20;
                        }
                        g.DrawLine(pen, begin, end);
                        g.FillEllipse(brush, begin.X - 10, begin.Y - 10, 20, 20);
                    }
                    #endregion
                }
                #region 绘制点
                for (int i = 0; i < point1.Count; i++)
                {
                    g.DrawString(point1[i].PointName, new Font("宋体", 20), Brushes.Blue, (float)(point1[i].Y - (int)ymin + 10) * 20 + 10f, -(float)(point1[i].X - (int)xmax - 10) * 20 + 10f);
                }
                #endregion
                pictureBox1.Image = image;
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        #endregion
        #region 保存报告
        private void 数据保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存报告为txt文件";
                save.Filter = "(txt文件)|*.txt";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(save.FileName))
                    {
                        sw.Write(richTextBox1.Text);
                    }
                }
                MessageBox.Show("保存报告成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        #endregion
        #region 保存图形
        private void 绘图保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "保存图形为jpg";
                save.Filter = "(jpg文件)|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image.Save(save.FileName);
                }
                MessageBox.Show("保存图片成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        #endregion
        #region 刷新
        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
        #endregion
        #region 帮助
        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("不规则三角网(TIN)体积计算");
        }
        #endregion
        #region 时间控件
        private void Form1_Load(object sender, EventArgs e)
        {
            DGV.AllowUserToAddRows = false;

            toolStripStatusLabel3.Text = DateTime.Now.ToString();
            timer1.Enabled = true;
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
        }
        #endregion

        #region 退出
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion
        #region 放大
        private void Bigger_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }
        }
        #endregion
        #region 缩小
        private void Smaller_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }
        #endregion

        //private void 清除ToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    //point.Clear();
        //    //t.Clear();
        //    point1.Clear();
        //    T1.Clear();
        //    S.Clear();
        //    V.Clear();
        //    this.DGV.Rows.Clear();
        //    this.richTextBox1.Text = "";
        //    this.DH.Text = "请输入设计高程";
        //    Graphics g = this.pictureBox1.CreateGraphics();
        //    g.Clear(Color.White);
        //    g.Dispose();
        //}

    }
}
