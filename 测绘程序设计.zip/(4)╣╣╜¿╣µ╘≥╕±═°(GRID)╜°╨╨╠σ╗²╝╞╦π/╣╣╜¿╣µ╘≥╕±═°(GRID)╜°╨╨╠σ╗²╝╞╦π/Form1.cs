﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 构建规则格网_GRID_进行体积计算
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //初始化表格
        public void InitializeDGV()
        {
            DGV_origin.Rows.Clear();
            DGV_origin.AllowUserToAddRows = false;
            DGV_origin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_origin.ColumnCount = 4;
            DGV_origin.Columns[0].Name = "点名";
            DGV_origin.Columns[1].Name = "X坐标";
            DGV_origin.Columns[2].Name = "Y坐标";
            DGV_origin.Columns[3].Name = "高程";

            DGV_TU.Rows.Clear();
            DGV_TU.AllowUserToAddRows = false;
            DGV_TU.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_TU.ColumnCount = 4;
            DGV_TU.Columns[0].Name = "点号";
            DGV_TU.Columns[1].Name = "X坐标";
            DGV_TU.Columns[2].Name = "Y坐标";
            DGV_TU.Columns[3].Name = "高程";

            DGV_Net.Rows.Clear();
            DGV_Net.AllowUserToAddRows = false;
            DGV_Net.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Net.ColumnCount = 5;
            DGV_Net.Columns[0].Name = "编号";
            DGV_Net.Columns[1].Name = "X坐标";
            DGV_Net.Columns[2].Name = "Y坐标";
            DGV_Net.Columns[3].Name = "高程";
            DGV_Net.Columns[4].Name = "单体积";
        }
        #region 定义变量
        Point2[,] gedian;//存储格点数据
        List<Point1> M;//记录散点的数据
        List<Point1> S;//存储凸包点的数据
        double Xmax, Ymax, Xmin, Ymin;//定义最大最小X、Y坐标值用于绘图
        double gaocheng, bian, lingRate;//存储基准高程,网格边长,邻域比
        int a, b;//存储格网横向个数a,纵向个数b
        double R0, totalV;//存储总体积
        #endregion
        static Bitmap image;
        //初始化数据
        public void Chushihua()
        {
            M = new List<Point1>();
            S = new List<Point1>();
        }

        #region 打开并读入数据到表格
        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                InitializeDGV();//清空表格并初始化
                open.Title = "打开GRID初始数据";
                open.Filter = "文本文件|*.txt";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    using (StreamReader sr = new StreamReader(open.FileName, Encoding.Default))
                    {
                        for (int i = 0; !sr.EndOfStream; i++)
                        {
                            string[] item = sr.ReadLine().Split(',');
                            DGV_origin.Rows.Add();
                            for (int j = 0; j < 4; j++)
                            {
                                DGV_origin.Rows[i].Cells[j].Value = item[j];
                            }
                        }
                    }//using
                }//if
            }//try
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        #region 从表格导入数据并计算 生成报告
        private void 计算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //初始化数据
            Chushihua();
            //清空表格
            DGV_Net.Rows.Clear();
            DGV_TU.Rows.Clear();
            string error = "";
            //读取散点数据 并加到列表M中
            try
            {
                for (int i = 0; i < DGV_origin.RowCount; i++)
                {
                    error = i + "行数据错误";
                    Point1 p = new Point1();
                    p.PointName = DGV_origin.Rows[i].Cells[0].Value.ToString();
                    p.X = Convert.ToDouble(DGV_origin.Rows[i].Cells[1].Value);
                    p.Y = Convert.ToDouble(DGV_origin.Rows[i].Cells[2].Value);
                    p.H = Convert.ToDouble(DGV_origin.Rows[i].Cells[3].Value);
                    M.Add(p);
                }
            }
            catch
            {
                MessageBox.Show(error);
                return;
            }
            //读取基准高程 网格边长 邻域比
            try
            {
                error = "基本信息错误";
                gaocheng = Convert.ToDouble(txt_gaocheng.Text);
                bian = Convert.ToDouble(txt_bian.Text);
                lingRate = Convert.ToDouble(txt_lingRate.Text);
            }
            catch
            {
                MessageBox.Show(error);
                return;
            }
            try
            {
                //凸包生成
                #region 1.1查找基点
                double min = M[0].Y;//先定义一个存储y值最小的点
                int dianhao = 0;//存储最小值的点号
                for (int i = 0; i < M.Count; i++)//遍历离散点集M
                {
                    if (M[i].Y < min)
                    {
                        min = M[i].Y;
                        dianhao = i;
                    }
                    else if (M[i].Y == min && M[i].X < M[dianhao].X)
                    {
                        min = M[i].Y;
                        dianhao = i;
                    }
                }
                #endregion
                #region 1.2计算夹角并从小到大排序
                Point1 f = new Point1();//基点与一号点互换位置，方便下一步循环
                f = M[0];
                M[0] = M[dianhao];
                M[dianhao] = f;
                for (int i = 1; i < M.Count; i++)
                {
                    double R = 0, x1, y1;//定义夹角 deltaX deltaY
                    x1 = M[i].X - M[0].X;
                    y1 = M[i].Y - M[0].Y;
                    if (x1 == 0)//特殊情况
                    { M[i].angle = Math.PI / 2; }
                    else
                    {
                        R = Math.Atan(Math.Abs(y1) / Math.Abs(x1));//计算每个向量和X轴正方向的夹角
                        if (x1 < 0)
                        { R = Math.PI - R; }
                        M[i].angle = R;
                    }
                }
                //冒泡排序 按角度从小到大重新排列M
                for (int i = 0; i < M.Count; i++)
                {
                    for (int j = 0; j < M.Count - i - 1; j++)
                    {
                        if (M[j].angle > M[j + 1].angle)
                        {
                            f = M[j + 1];
                            M[j + 1] = M[j];
                            M[j] = f;
                        }
                    }
                }
                #endregion
                #region 1.3建立由凸包点构成的列表或者堆栈S
                S.Add(M[0]);
                S.Add(M[1]);
                S.Add(M[2]);
                int top = 2;
                for (int i = 3; i < M.Count; i++)
                {
                    while ((S[top - 1].X - S[top].X) * (M[i].Y - S[top].Y) - (S[top - 1].Y - S[top].Y) * (M[i].X - S[top].X) > 0)//大于0左转
                    { top--; }
                    if (top < S.Count - 1)
                    { S[top + 1] = M[i]; }
                    else
                    { S.Add(M[i]); }
                    top++;
                }
                S.Add(S[0]);
                #endregion
                //2.规则格网的生成
                #region 2.1建立外包矩形，并进行二维格网划分
                Xmax = S[0].X;
                Xmin = S[0].X;
                Ymax = S[0].Y;
                Ymin = S[0].Y;//遍历所有S中的凸包点 找到x、y分量的最大值与最小值
                for (int i = 0; i < S.Count; i++)
                {
                    if (Xmax < S[i].X) { Xmax = S[i].X; }
                    if (Ymax < S[i].Y) { Ymax = S[i].Y; }
                    if (Xmin > S[i].X) { Xmin = S[i].X; }
                    if (Ymin > S[i].Y) { Ymin = S[i].Y; }
                }
                a = (int)((Ymax - Ymin) / bian) + 1;//存储格网点个数，比格网个数多一个
                b = (int)((Xmax - Xmin) / bian) + 1;
                #endregion
                #region 2.2判断格网中心点是否在凸包内
                gedian = new Point2[a, b];//初始化格点
                for (int i = 0; i < a; i++)
                    for (int j = 0; j < b; j++)
                    {
                        Point2 f1 = new Point2();
                        int nw = 0;
                        f1.dianhao = i + "," + j;
                        f1.X = ((j + j + 1) / 2d) * bian + Xmin;
                        f1.Y = ((i + i + 1) / 2d) * bian + Ymin;
                        for (int c = 0; c < S.Count - 1; c++)
                        {
                            double x1 = 0;
                            if (f1.Y >= S[c].Y && f1.Y <= S[c + 1].Y
                             || f1.Y <= S[c].Y && f1.Y >= S[c + 1].Y)//如果y分量位于连个断电的分量之间
                            {
                                x1 = (S[c + 1].X - S[c].X) / (S[c + 1].Y - S[c].Y) * (f1.Y - S[c].Y) + S[c].X;
                                if (x1 > f1.X)
                                { nw++; }
                            }
                        }
                        f1.NW = nw;
                        gedian[i, j] = f1;
                    }
                #endregion
                #region 3.体积计算
                //3.1采用反距离加权法求格网四个顶点的高程
                R0 = lingRate * (a + b) / 2 * bian;//半径
                //R0 = lingRate * (Ymax - Ymin + Xmax - Xmin) / 2 * bian;
                int m = 0;//用来输出格网表格数据
                totalV = 0;
                //计算体积
                for (int i = 0; i < a; i++)
                {
                    for (int j = 0; j < b; j++)//对每个格网点进行遍历
                    {
                        if (gedian[i, j].NW % 2 == 1)//在凸包点内部
                        {
                            double h1, h2, h3, h4;
                            h1 = Method.GaoCheng(gedian[i, j].X - 0.5 * bian, gedian[i, j].Y - 0.5 * bian, R0, M);
                            h2 = Method.GaoCheng(gedian[i, j].X - 0.5 * bian, gedian[i, j].Y + 0.5 * bian, R0, M);
                            h3 = Method.GaoCheng(gedian[i, j].X + 0.5 * bian, gedian[i, j].Y + 0.5 * bian, R0, M);
                            h4 = Method.GaoCheng(gedian[i, j].X + 0.5 * bian, gedian[i, j].Y - 0.5 * bian, R0, M);
                            gedian[i, j].H = (h1 + h2 + h3 + h4) / 4;
                            gedian[i, j].Vi = ((h1 + h2 + h3 + h4) / 4 - gaocheng) * bian * bian;
                            totalV += gedian[i, j].Vi;

                            #region 输出格网点信息
                            DGV_Net.Rows.Add();
                            DGV_Net.Rows[m].Cells[0].Value = gedian[i, j].dianhao;
                            DGV_Net.Rows[m].Cells[1].Value = gedian[i, j].X;
                            DGV_Net.Rows[m].Cells[2].Value = gedian[i, j].Y;
                            DGV_Net.Rows[m].Cells[3].Value = gedian[i, j].H;
                            DGV_Net.Rows[m].Cells[4].Value = gedian[i, j].Vi;
                            m++;
                            #endregion
                        }
                    }
                }
                #endregion
                //输出凸包点信息
                for (int i = 0; i < S.Count; i++)
                {
                    DGV_TU.Rows.Add();
                    DGV_TU.Rows[i].Cells[0].Value = S[i].PointName;
                    DGV_TU.Rows[i].Cells[1].Value = S[i].X;
                    DGV_TU.Rows[i].Cells[2].Value = S[i].Y;
                    DGV_TU.Rows[i].Cells[3].Value = S[i].H;
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        private void 生成报告ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                #region 生成报告
                richTextBox1.Text = "构建规则格网(GRID)进行体积计算\n";
                richTextBox1.Text += "----------基本信息----------\n";
                richTextBox1.Text += "基准高程:" + gaocheng + "\n";
                richTextBox1.Text += "单位格网边长:" + bian + "\n";
                richTextBox1.Text += "格网纵向个数:" + b + "\n";
                richTextBox1.Text += "格网横向个数:" + a + "\n";
                richTextBox1.Text += "单位格网总数:" + (a * b) + "\n";
                richTextBox1.Text += "总体积:" + Math.Round(totalV, 3) + "\n\n";
                richTextBox1.Text += "----------凸包点信息----------\n";
                richTextBox1.Text += "点名    \tX坐标    \tY坐标    \tH高程\n";
                for (int i = 0; i < S.Count; i++)
                {
                    richTextBox1.Text += string.Format("{0,-8}\t{1,-8}\t{2,-8}\t{3,-8}\t",
                        S[i].PointName, S[i].X, S[i].Y, S[i].H) + "\n";
                }
                richTextBox1.Text += "\n----------网格处理数据----------\n";
                richTextBox1.Text += "编号    \tX坐标    \tY坐标    \t高程    \t\t土方\n";
                for (int i = 0; i < DGV_Net.RowCount; i++)
                {
                    richTextBox1.Text += string.Format("{0,-8}\t{1,-8}\t{2,-8}\t{3,-16}\t{4,-16}",
                        DGV_Net.Rows[i].Cells[0].Value, DGV_Net.Rows[i].Cells[1].Value,
                        DGV_Net.Rows[i].Cells[2].Value, DGV_Net.Rows[i].Cells[3].Value,
                        DGV_Net.Rows[i].Cells[4].Value) + "\n";
                }
                #endregion
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        #endregion
        #region 利用计算结果绘图
        private void 绘图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages[1];
            try
            {
                //找到最大最小X、Y
                Xmin = 100000000; Ymin = 100000000; Xmax = 0; Ymax = 0;
                for (int i = 0; i < M.Count; i++)
                {
                    if (Xmin > M[i].X) { Xmin = M[i].X; }
                    if (Ymin > M[i].Y) { Ymin = M[i].Y; }
                    if (Xmax < M[i].X) { Xmax = M[i].X; }
                    if (Ymax < M[i].Y) { Ymax = M[i].Y; }
                }
                //定义image的长和宽大小
                int width = (int)(Xmax - Xmin) * 30 + 200;
                int height = (int)(Ymax - Ymin) * 30 + 200;
                image = new Bitmap(width, height);
                //定义画布 画笔 笔刷
                Graphics g = Graphics.FromImage(image);
                g.Clear(Color.White);
                Pen pline = new Pen(Color.Black, 2);
                Pen Pfont = new Pen(Color.Red, 2.5f);
                SolidBrush redbrush = new SolidBrush(Color.Red);
                SolidBrush yellowbrush = new SolidBrush(Color.Yellow);
                SolidBrush blackbrush = new SolidBrush(Color.Black);
                //画坐标轴
                PointF originPoint = new PointF(50, height - 50);
                PointF[] Xzhou = new PointF[3] { new PointF(width - 50, height - 50), new PointF(width - 100, height - 60), new PointF(width - 100, height - 40) };
                PointF[] Yzhou = new PointF[3] { new PointF(50, 50), new PointF(40, 100), new PointF(60, 100) };
                g.DrawLine(pline, Yzhou[0], originPoint);//画Y轴
                g.DrawLine(pline, Xzhou[0], originPoint);//画X轴
                g.FillPolygon(blackbrush, Yzhou);//Y轴箭头
                g.FillPolygon(blackbrush, Xzhou);//X轴箭头
                g.DrawString("X", new Font("宋体", 20), blackbrush, Xzhou[0]);//X轴标注
                g.DrawString("Y", new Font("宋体", 20), blackbrush, Yzhou[0]);//Y轴标注
                //转化S点集边缘点的坐标 连线 填充
                PointF[] borderPoint = new PointF[S.Count];
                for (int i = 0; i < S.Count; i++)
                {
                    borderPoint[i].X = -(float)((S[i].X - Xmax) * 30 - 100);
                    borderPoint[i].Y = (float)((S[i].Y - Ymin) * 30 + 100);
                }
                g.DrawLines(pline, borderPoint);
                g.FillPolygon(yellowbrush, borderPoint);
                //画格网 (应该还可以优化)
                for (int i = 0; i < a; i++)
                {
                    for (int j = 0; j < b; j++)
                    {
                        g.DrawLine(pline, (int)((j * bian) * 30 + 100), -(int)((i * bian + Ymin - Ymax) * 30 - 100), (int)(((j) * bian) * 30 + 100), -(int)(((i + 1) * bian + Ymin - Ymax) * 30 - 100));
                        g.DrawLine(pline, (int)(((j) * bian) * 30 + 100), -(int)(((i + 1) * bian + Ymin - Ymax) * 30 - 100), (int)(((j + 1) * bian) * 30 + 100), -(int)(((i + 1) * bian + Ymin - Ymax) * 30 - 100));
                        g.DrawLine(pline, (int)(((j + 1) * bian) * 30 + 100), -(int)(((i + 1) * bian + Ymin - Ymax) * 30 - 100), (int)(((j + 1) * bian) * 30 + 100), -(int)(((i) * bian + Ymin - Ymax) * 30 - 100));
                        g.DrawLine(pline, (int)(((j + 1) * bian) * 30 + 100), -(int)(((i) * bian + Ymin - Ymax) * 30 - 100), (int)(((j) * bian) * 30 + 100), -(int)(((i) * bian + Ymin - Ymax) * 30 - 100));
                    }
                }
                //转化M点集的坐标 并画点 注释点号
                int D = 8;
                PointF[] po = new PointF[M.Count];
                for (int i = 0; i < M.Count; i++)
                {
                    po[i].X = -(float)((M[i].X - Xmax) * 30 - 100);
                    po[i].Y = (float)((M[i].Y - Ymin) * 30 + 100);
                    g.DrawEllipse(pline, po[i].X - D / 2, po[i].Y - D / 2, D, D);
                    g.DrawString(M[i].PointName, new Font("宋体", 15), redbrush, po[i]);
                }
                pictureBox1.Image = image;
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        #endregion
        #region 保存
        private void 数据保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "规则格网(GRID)数据保存";
                save.Filter = "(txt文件)|*.txt";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(save.FileName))
                    {
                        sw.Write(richTextBox1.Text);
                    }
                }
                MessageBox.Show("保存报告成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void 绘图保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                save.Title = "规则格网(GRID)图形保存";
                save.Filter = "(jpg文件)|*.jpg";
                if (save.ShowDialog() == DialogResult.OK)
                {
                    image.Save(save.FileName);
                }
                MessageBox.Show("保存图片成功!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        #endregion
        #region 其它功能
        private void Bigger_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width < 5000)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 1.2);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 1.2);
            }
        }

        private void Smaller_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 100)
            {
                pictureBox1.Width = Convert.ToInt32(pictureBox1.Width * 0.8);
                pictureBox1.Height = Convert.ToInt32(pictureBox1.Height * 0.8);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
            timer1.Enabled = true;
            timer1.Interval = 1000;

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("构建规则格网(GRID)进行体积计算\n\tpotter");
        }

        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();
        }
        private void 一键计算_Click(object sender, EventArgs e)
        {
            计算ToolStripMenuItem_Click(sender, e);
            生成报告ToolStripMenuItem_Click(sender, e);
        }
        #endregion
    }
}
