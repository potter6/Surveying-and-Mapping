﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace 导线近似平差计算_新_
{
    public class Method
    {
        /// <summary>
        /// 初始化表格
        /// </summary>
        /// <param name="dgv"></param>
        public static void InitialDataGridView(DataGridView dgv)
        {
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.ColumnHeadersHeight = 28;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgv.AllowUserToAddRows = false;//将这个加上后就解决了那个报错问题 加在了计算按钮事件那里
            dgv.RowHeadersVisible = false;
            dgv.ColumnCount = 8;
            dgv.Columns[0].Name = "点名";
            dgv.Columns[1].Name = "观测角(d.ms)";
            dgv.Columns[2].Name = "方位角(d.ms)";
            dgv.Columns[3].Name = "距离(m)";
            dgv.Columns[4].Name = "X增量(m)";
            dgv.Columns[5].Name = "Y增量(m)";
            dgv.Columns[6].Name = "X坐标(m)";
            dgv.Columns[7].Name = "Y坐标(m)";
        }
        /// <summary>
        /// 从txt中读取数据到表格
        /// </summary>
        /// <param name="dgv"></param>
        public static void ReadFromTxt(DataGridView dgv)
        {
            dgv.Rows.Clear();
            var open = new OpenFileDialog();
            open.Title = "打开txt数据文件";
            open.Filter = "(txt文件)|*.txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                using (var sr = new StreamReader(open.FileName))
                {
                    sr.ReadLine();
                    string[] str;
                    List<string[]> arrstr = new List<string[]>();//用于存储已知数据
                    int q = 0;//存储行号
                    double s;//存储角度
                    for (int i = 0; i < 4; i++)//存储已知数据
                    {
                        str = sr.ReadLine().Split(',');
                        arrstr.Add(str);
                    }
                    dgv.Rows.Add();
                    for (int i = 0; i < 2; i++)
                    {
                        dgv.Rows.Add();
                        dgv.Rows[i * 2].Cells[0].Value = arrstr[i][0];
                        dgv.Rows[i * 2].Cells[6].Value = arrstr[i][1];
                        dgv.Rows[i * 2].Cells[7].Value = arrstr[i][2];
                        q++;
                    }
                    while (true)
                    {
                        double jiaodu;
                        str = sr.ReadLine().Split(',');
                        dgv.Rows.Add();
                        dgv.Rows[q].Cells[0].Value = str[0];
                        str = sr.ReadLine().Split(',');
                        jiaodu = Convert.ToDouble(str[2]);
                        s = jiaodu;
                        str = sr.ReadLine().Split(',');
                        if (str.Length == 1) break;
                        jiaodu = Convert.ToDouble(str[2]) - jiaodu;
                        dgv.Rows[q].Cells[1].Value = caculate.dmstojiaodu(jiaodu);
                        dgv.Rows.Add();
                        q += 2;
                    }
                    for (int i = 0; i < 2; i++)
                    {
                        dgv.Rows[q - 2 + i * 2].Cells[0].Value = arrstr[i + 2][0];
                        dgv.Rows[q - 2 + i * 2].Cells[6].Value = arrstr[i + 2][1];
                        dgv.Rows[q - 2 + i * 2].Cells[7].Value = arrstr[i + 2][2];
                    }
                    q = 0;
                    dgv.Rows[3].Cells[3].Value = s;//把存储的边长输出
                    while (true)
                    {
                        q += 2;
                        str = sr.ReadLine().Split(',');
                        dgv.Rows[3 + q].Cells[3].Value = str[2];
                        if (!sr.EndOfStream)
                        {
                            sr.ReadLine();
                        }
                        else
                        {
                            break;
                        }
                    }
                }//using
            }//if
        }//ReadFromTxt

        /// <summary>
        /// 保存报告
        /// </summary>
        /// <param name="_richtextbox"></param>
        public static void SaveReport(RichTextBox _richtextbox)
        {
            var save = new SaveFileDialog();
            save.Title = "保存报告为txt文件";
            save.Filter = "(txt文件)|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                using (var sw = new StreamWriter(save.FileName))
                {
                    sw.Write(_richtextbox.Text);
                }
            }
            MessageBox.Show("保存报告成功！");
        }


    }//class

    //点数据
    //用于存放点名和坐标
    public class Npoint
    {
        public string Name;
        public float X;
        public float Y;

        public Npoint(string str, float x, float y)
        {
            this.Name = str;
            this.X = x;
            this.Y = y;
        }
    }
}//namespace

