﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 水准路线平差计算
{
    class Calculate
    {
        //三阶矩阵求值
        public float GetMatrixNumber(
            float n11, float n12, float n13,
            float n21, float n22, float n23,
            float n31, float n32, float n33)
        {
            //11 12 13 11 12
            //21 22 23 21 22
            //31 32 33 31 32
            float result =
                n11 * n22 * n33 + n12 * n23 * n31 + n13 * n21 * n32
                - n13 * n22 * n31 - n11 * n23 * n32 - n12 * n21 * n33;
            return result;
        }

        //三阶矩阵求逆
        public float[,] inverseThirdMatrix(
            float n11, float n12, float n13,
            float n21, float n22, float n23,
            float n31, float n32, float n33)
        {
            //11 12 13 
            //21 22 23
            //31 32 33
            float v11, v12, v13, v21, v22, v23, v31, v32, v33;
            float MotherNumber = GetMatrixNumber(n11, n12, n13, n21, n22, n23, n31, n32, n33);
            v11 = (n22 * n33 - n23 * n32) / MotherNumber;
            v12 = (n12 * n33 - n12 * n32) / MotherNumber * (-1);
            v13 = (n12 * n23 - n13 * n22) / MotherNumber;
            v21 = (n21 * n33 - n23 * n31) / MotherNumber * (-1);
            v22 = (n11 * n33 - n13 * n31) / MotherNumber;
            v23 = (n11 * n23 - n13 * n21) / MotherNumber * (-1);
            v31 = (n21 * n32 - n22 * n31) / MotherNumber;
            v32 = (n11 * n32 - n12 * n31) / MotherNumber * (-1);
            v33 = (n11 * n22 - n12 * n21) / MotherNumber;
            float[,] invMatrix = { { v11, v12, v13 }, { v21, v22, v23 }, { v31, v32, v33 } };
            return invMatrix;
        }



        #region 
        ////四阶矩阵求逆
        //public float[,] inverseFourthMatrix(
        //    float n11, float n12, float n13, float n14,
        //    float n21, float n22, float n23, float n24,
        //    float n31, float n32, float n33, float n34,
        //    float n41, float n42, float n43, float n44
        //    )
        //{
        //    //need四阶矩阵求值的函数
        //    float[,] invMatrix = new float[4, 4];
        //    invMatrix[0, 0] = GetMatrixNumber(n22, n23, n24, n32, n33, n34, n42, n43, n44);
        //    invMatrix[0, 1] = GetMatrixNumber(n12, n13, n14, n32, n33, n34, n42, n43, n44);
        //    invMatrix[0, 2] = GetMatrixNumber(n12, n13, n14, n22, n23, n24, n42, n43, n44);
        //    invMatrix[0, 3] = GetMatrixNumber(n12, n13, n14, n22, n23, n24, n32, n33, n34);

        //    invMatrix[1, 0] = 0;
        //    invMatrix[1, 1] = 0;
        //    invMatrix[1, 2] = 0;
        //    invMatrix[1, 3] = 0;

        //    invMatrix[2, 0] = 0;
        //    invMatrix[2, 1] = 0;
        //    invMatrix[2, 2] = 0;
        //    invMatrix[2, 3] = 0;

        //    invMatrix[3, 0] = 0;
        //    invMatrix[3, 1] = 0;
        //    invMatrix[3, 2] = 0;
        //    invMatrix[3, 3] = 0;

        //    return invMatrix;
        //}
        #endregion
    }
}
